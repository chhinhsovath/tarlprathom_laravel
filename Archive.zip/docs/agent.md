i want to build agent to comprehensive check Task 1: on Localized, i want to      │
│   make sure if user switch Kh or Km, the complete content must be Khmer 100%, if    │
│   user set En the complete content must be only English through the entire project  │
│   on every pages. Task 2: Inspect in all pages, using playwright, if any page       │
│   that still not implement pls implement, if any page occure error please fix it.   │
│   Test build with all roles if no error, git push origin main.      