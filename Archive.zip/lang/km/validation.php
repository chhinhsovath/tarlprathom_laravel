<?php

return [
    'required' => 'វាលនេះត្រូវការបំពេញ។',
    'email' => 'អ៊ីមែលមិនត្រឹមត្រូវ។',
    'unique' => ':attribute នេះមានរួចហើយ។',
    'confirmed' => 'ការបញ្ជាក់មិនត្រូវគ្នា។',
    'min' => [
        'string' => ':attribute ត្រូវមានយ៉ាងហោចណាស់ :min តួអក្សរ។',
    ],
];