<div>
    <div class="bg-white p-6 rounded-lg shadow">
        <!-- Chart Controls -->
        <div class="mb-6 space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Chart Type')); ?></label>
                    <select wire:model.live="chartType" class="w-full rounded-md border-gray-300 shadow-sm">
                        <option value="studentsBySchool"><?php echo e(__('Students by School')); ?></option>
                        <option value="assessmentsByLevel"><?php echo e(__('Assessments by Level')); ?></option>
                        <option value="mentoringTrend"><?php echo e(__('Mentoring Trend')); ?></option>
                        <option value="studentProgress"><?php echo e(__('Student Progress')); ?></option>
                    </select>
                </div>
                
                <?php if($chartType === 'assessmentsByLevel'): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Filter by School')); ?></label>
                    <select wire:model.live="filterSchool" class="w-full rounded-md border-gray-300 shadow-sm">
                        <option value=""><?php echo e(__('All Schools')); ?></option>
                        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($school->id); ?>"><?php echo e($school->school_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>
                
                <?php if($chartType === 'mentoringTrend'): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Date From')); ?></label>
                    <input type="date" wire:model.live="filterDateFrom" class="w-full rounded-md border-gray-300 shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Date To')); ?></label>
                    <input type="date" wire:model.live="filterDateTo" class="w-full rounded-md border-gray-300 shadow-sm">
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Chart Container -->
        <div class="relative" style="height: 400px;">
            <canvas id="chartCanvas-<?php echo e($chartType); ?>" wire:ignore></canvas>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script>
        document.addEventListener('livewire:initialized', () => {
            let chart = null;
            
            function renderChart() {
                const ctx = document.getElementById('chartCanvas-<?php echo e($chartType); ?>');
                if (!ctx) return;
                
                if (chart) {
                    chart.destroy();
                }
                
                const chartData = <?php echo json_encode($chartData, 15, 512) ?>;
                const chartType = <?php echo json_encode($chartType, 15, 512) ?>;
                
                let type = 'bar';
                if (chartType === 'mentoringTrend' || chartType === 'studentProgress') {
                    type = 'line';
                }
                if (chartType === 'assessmentsByLevel') {
                    type = 'pie';
                }
                
                chart = new Chart(ctx, {
                    type: type,
                    data: chartData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'top',
                            },
                            title: {
                                display: false
                            },
                            datalabels: {
                                display: function(context) {
                                    return context.dataset.data[context.dataIndex] > 0;
                                },
                                color: function(context) {
                                    return type === 'pie' ? 'white' : 'black';
                                },
                                font: {
                                    weight: 'bold',
                                    size: 12
                                },
                                formatter: function(value, context) {
                                    if (type === 'pie') {
                                        const total = context.dataset.data.reduce((sum, val) => sum + val, 0);
                                        const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                        return percentage > 0 ? percentage + '%' : '';
                                    }
                                    return value;
                                },
                                anchor: 'center',
                                align: type === 'bar' ? 'top' : 'center'
                            }
                        },
                        scales: type !== 'pie' ? {
                            y: {
                                beginAtZero: true
                            }
                        } : {}
                    },
                    plugins: [ChartDataLabels]
                });
            }
            
            renderChart();
            
            Livewire.on('chartDataUpdated', () => {
                setTimeout(() => renderChart(), 100);
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/livewire/chart-component.blade.php ENDPATH**/ ?>