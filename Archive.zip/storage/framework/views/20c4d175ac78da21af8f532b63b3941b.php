<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('School Comparison Report')); ?></h3>
                        <a href="<?php echo e(route('reports.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                            ← <?php echo e(__('Back to Reports')); ?>

                        </a>
                    </div>
                    
                    <!-- Filters -->
                    <form method="GET" action="<?php echo e(route('reports.school-comparison')); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label for="subject" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Subject')); ?></label>
                            <select name="subject" id="subject" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="khmer" <?php echo e($subject == 'khmer' ? 'selected' : ''); ?>><?php echo e(__('Khmer')); ?></option>
                                <option value="math" <?php echo e($subject == 'math' ? 'selected' : ''); ?>><?php echo e(__('Math')); ?></option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="cycle" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Test Cycle')); ?></label>
                            <select name="cycle" id="cycle" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="baseline" <?php echo e($cycle == 'baseline' ? 'selected' : ''); ?>><?php echo e(__('Baseline')); ?></option>
                                <option value="midline" <?php echo e($cycle == 'midline' ? 'selected' : ''); ?>><?php echo e(__('Midline')); ?></option>
                                <option value="endline" <?php echo e($cycle == 'endline' ? 'selected' : ''); ?>><?php echo e(__('Endline')); ?></option>
                            </select>
                        </div>
                        
                        <div class="flex items-end">
                            <button type="submit" class="w-full inline-flex justify-center items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700">
                                <?php echo e(__('Apply Filters')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Comparison Chart -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Performance Comparison')); ?></h4>
                    
                    <div class="relative" style="height: 400px;">
                        <canvas id="comparisonChart"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Detailed Comparison Table -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Detailed Comparison')); ?></h4>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('School')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Total Assessed')); ?>

                                    </th>
                                    <?php
                                        $allLevels = $subject === 'khmer' 
                                            ? ['Beginner', 'Letter Reader', 'Word Level', 'Paragraph Reader', 'Story Reader', 'Comp. 1', 'Comp. 2']
                                            : ['Beginner', '1-Digit', '2-Digit', 'Subtraction', 'Division', 'Word Problem'];
                                    ?>
                                    <?php $__currentLoopData = $allLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__($level)); ?>

                                    </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $comparisonData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo e($data['school']); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e(number_format($data['total_assessed'])); ?>

                                    </td>
                                    <?php $__currentLoopData = $allLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                                        <?php if(isset($data['levels'][$level])): ?>
                                            <?php echo e($data['levels'][$level]); ?>

                                            <br>
                                            <span class="text-xs text-gray-400">
                                                (<?php echo e(number_format(($data['levels'][$level] / $data['total_assessed']) * 100, 1)); ?>%)
                                            </span>
                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="<?php echo e(count($allLevels) + 2); ?>" class="px-6 py-4 text-center text-sm text-gray-500">
                                        <?php echo e(__('No data available for the selected filters')); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
        $(document).ready(function() {
            const comparisonData = <?php echo json_encode($comparisonData, 15, 512) ?>;
            const subject = <?php echo json_encode($subject, 15, 512) ?>;
            
            if (comparisonData.length > 0) {
                // Prepare data for chart
                const schools = comparisonData.map(d => d.school);
                const levels = subject === 'khmer' 
                    ? ['Beginner', 'Letter Reader', 'Word Level', 'Paragraph Reader', 'Story Reader', 'Comp. 1', 'Comp. 2']
                    : ['Beginner', '1-Digit', '2-Digit', 'Subtraction', 'Division', 'Word Problem'];
                
                const datasets = levels.map((level, index) => {
                    const colors = [
                        '#ef4444', // red
                        '#f59e0b', // amber
                        '#eab308', // yellow
                        '#84cc16', // lime
                        '#22c55e', // green
                        '#10b981', // emerald
                        '#14b8a6'  // teal
                    ];
                    
                    return {
                        label: level,
                        data: comparisonData.map(d => d.levels[level] || 0),
                        backgroundColor: colors[index],
                        stack: 'stack0'
                    };
                });
                
                // Create stacked bar chart
                const ctx = document.getElementById('comparisonChart').getContext('2d');
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: schools,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            title: {
                                display: true,
                                text: '<?php echo e(__("Student Distribution by School and Level")); ?>'
                            },
                            tooltip: {
                                callbacks: {
                                    afterLabel: function(context) {
                                        const total = comparisonData[context.dataIndex].total_assessed;
                                        const percentage = ((context.raw / total) * 100).toFixed(1);
                                        return percentage + '%';
                                    }
                                }
                            }
                        },
                        scales: {
                            x: {
                                stacked: true,
                                title: {
                                    display: true,
                                    text: '<?php echo e(__("School")); ?>'
                                }
                            },
                            y: {
                                stacked: true,
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: '<?php echo e(__("Number of Students")); ?>'
                                }
                            }
                        }
                    }
                });
            }
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/reports/school-comparison.blade.php ENDPATH**/ ?>