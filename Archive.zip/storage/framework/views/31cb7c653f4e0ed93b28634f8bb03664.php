<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Mentoring Impact Report')); ?></h3>
                        <a href="<?php echo e(route('reports.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                            ← <?php echo e(__('Back to Reports')); ?>

                        </a>
                    </div>
                    
                    <!-- Date Range Filter -->
                    <form method="GET" action="<?php echo e(route('reports.mentoring-impact')); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Start Date')); ?></label>
                            <input type="date" name="start_date" id="start_date" value="<?php echo e($startDate->format('Y-m-d')); ?>" 
                                   class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        
                        <div>
                            <label for="end_date" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('End Date')); ?></label>
                            <input type="date" name="end_date" id="end_date" value="<?php echo e($endDate->format('Y-m-d')); ?>" 
                                   class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        
                        <div class="flex items-end">
                            <button type="submit" class="w-full inline-flex justify-center items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700">
                                <?php echo e(__('Apply Filters')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Impact Correlation Chart -->
            <?php if(count($schoolsWithImprovements) > 0): ?>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Mentoring Visits vs Performance Improvement')); ?></h4>
                    
                    <div class="relative" style="height: 400px;">
                        <canvas id="impactChart"></canvas>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- School Impact Summary -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('School Impact Summary')); ?></h4>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('School')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Total Visits')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Teachers Mentored')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Avg Mentoring Score')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Baseline Avg')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Latest Avg')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Improvement')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $schoolsWithImprovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo e($data['school']->school_name); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e(number_format($data['total_visits'])); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e(number_format($visitsBySchool[$data['school']->id]['unique_teachers'] ?? 0)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e(number_format($data['avg_mentoring_score'], 1)); ?>%
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e(number_format($data['baseline_avg'], 1)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e(number_format($data['latest_avg'], 1)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                            <?php if($data['improvement'] > 0): ?> bg-green-100 text-green-800
                                            <?php elseif($data['improvement'] < 0): ?> bg-red-100 text-red-800
                                            <?php else: ?> bg-gray-100 text-gray-800
                                            <?php endif; ?>">
                                            <?php if($data['improvement'] > 0): ?>+<?php endif; ?><?php echo e(number_format($data['improvement'], 1)); ?>

                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-4 text-center text-sm text-gray-500">
                                        <?php echo e(__('No data available for the selected period')); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Visit Details by School -->
            <?php if($visitsBySchool->count() > 0): ?>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Visit Details by School')); ?></h4>
                    
                    <div class="space-y-4">
                        <?php $__currentLoopData = $visitsBySchool; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schoolId => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded-lg p-4">
                            <h5 class="font-medium text-gray-900 mb-2"><?php echo e($data['school']->school_name); ?></h5>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <p class="text-sm text-gray-600">
                                        <?php echo e(__('Total Visits')); ?>: <?php echo e($data['total_visits']); ?> | 
                                        <?php echo e(__('Teachers')); ?>: <?php echo e($data['unique_teachers']); ?> |
                                        <?php echo e(__('Avg Score')); ?>: <?php echo e(number_format($data['average_score'], 1)); ?>%
                                    </p>
                                </div>
                                <div class="text-right">
                                    <button onclick="toggleVisitDetails('school-<?php echo e($schoolId); ?>')" 
                                            class="text-sm text-blue-600 hover:text-blue-800">
                                        <?php echo e(__('Show Details')); ?> ↓
                                    </button>
                                </div>
                            </div>
                            
                            <div id="school-<?php echo e($schoolId); ?>" class="hidden mt-4">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Date')); ?></th>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Teacher')); ?></th>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Mentor')); ?></th>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Score')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200">
                                        <?php $__currentLoopData = $data['visits']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($visit->visit_date->format('Y-m-d')); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-900"><?php echo e($visit->teacher->name); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($visit->mentor->name); ?></td>
                                            <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($visit->score); ?>%</td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
        function toggleVisitDetails(id) {
            const element = document.getElementById(id);
            element.classList.toggle('hidden');
        }
        
        <?php if(count($schoolsWithImprovements) > 0): ?>
        $(document).ready(function() {
            const impactData = <?php echo json_encode($schoolsWithImprovements, 15, 512) ?>;
            
            // Create scatter plot
            const ctx = document.getElementById('impactChart').getContext('2d');
            new Chart(ctx, {
                type: 'scatter',
                data: {
                    datasets: [{
                        label: '<?php echo e(__("Schools")); ?>',
                        data: impactData.map(d => ({
                            x: d.total_visits,
                            y: d.improvement,
                            label: d.school.school_name
                        })),
                        backgroundColor: 'rgba(59, 130, 246, 0.5)',
                        borderColor: 'rgba(59, 130, 246, 1)',
                        pointRadius: 8,
                        pointHoverRadius: 10
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: '<?php echo e(__("Correlation between Mentoring Visits and Performance Improvement")); ?>'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.raw.label + ': ' + 
                                           context.parsed.x + ' <?php echo e(__("visits")); ?>, ' +
                                           (context.parsed.y > 0 ? '+' : '') + context.parsed.y.toFixed(1) + ' <?php echo e(__("improvement")); ?>';
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: '<?php echo e(__("Number of Mentoring Visits")); ?>'
                            },
                            beginAtZero: true
                        },
                        y: {
                            title: {
                                display: true,
                                text: '<?php echo e(__("Performance Improvement")); ?>'
                            }
                        }
                    }
                }
            });
        });
        <?php endif; ?>
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/reports/mentoring-impact.blade.php ENDPATH**/ ?>