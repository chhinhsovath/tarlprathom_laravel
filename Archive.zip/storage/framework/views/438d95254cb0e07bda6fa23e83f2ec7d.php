<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Progress Tracking Report')); ?></h3>
                        <a href="<?php echo e(route('reports.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                            ← <?php echo e(__('Back to Reports')); ?>

                        </a>
                    </div>
                    
                    <!-- Filters -->
                    <form method="GET" action="<?php echo e(route('reports.progress-tracking')); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label for="school_id" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('School')); ?></label>
                            <select name="school_id" id="school_id" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value=""><?php echo e(__('All Schools')); ?></option>
                                <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($school->id); ?>" <?php echo e($schoolId == $school->id ? 'selected' : ''); ?>>
                                        <?php echo e($school->school_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="subject" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Subject')); ?></label>
                            <select name="subject" id="subject" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="khmer" <?php echo e($subject == 'khmer' ? 'selected' : ''); ?>><?php echo e(__('Khmer')); ?></option>
                                <option value="math" <?php echo e($subject == 'math' ? 'selected' : ''); ?>><?php echo e(__('Math')); ?></option>
                            </select>
                        </div>
                        
                        <div class="flex items-end">
                            <button type="submit" class="w-full inline-flex justify-center items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700">
                                <?php echo e(__('Apply Filters')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Progress Summary -->
            <?php if(count($progressData) > 0): ?>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Progress Summary')); ?></h4>
                    
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                        <?php
                            $totalStudents = count($progressData);
                            $improved = collect($progressData)->where('level_improved', '>', 0)->count();
                            $maintained = collect($progressData)->where('level_improved', '=', 0)->count();
                            $declined = collect($progressData)->where('level_improved', '<', 0)->count();
                            $avgScoreChange = collect($progressData)->avg('score_change');
                        ?>
                        
                        <div class="bg-green-50 p-4 rounded-lg">
                            <div class="text-2xl font-bold text-green-700"><?php echo e($improved); ?></div>
                            <div class="text-sm text-green-600"><?php echo e(__('Students Improved')); ?></div>
                            <div class="text-xs text-green-500"><?php echo e($totalStudents > 0 ? number_format(($improved / $totalStudents) * 100, 1) : 0); ?>%</div>
                        </div>
                        
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <div class="text-2xl font-bold text-blue-700"><?php echo e($maintained); ?></div>
                            <div class="text-sm text-blue-600"><?php echo e(__('Students Maintained')); ?></div>
                            <div class="text-xs text-blue-500"><?php echo e($totalStudents > 0 ? number_format(($maintained / $totalStudents) * 100, 1) : 0); ?>%</div>
                        </div>
                        
                        <div class="bg-red-50 p-4 rounded-lg">
                            <div class="text-2xl font-bold text-red-700"><?php echo e($declined); ?></div>
                            <div class="text-sm text-red-600"><?php echo e(__('Students Declined')); ?></div>
                            <div class="text-xs text-red-500"><?php echo e($totalStudents > 0 ? number_format(($declined / $totalStudents) * 100, 1) : 0); ?>%</div>
                        </div>
                        
                        <div class="bg-purple-50 p-4 rounded-lg">
                            <div class="text-2xl font-bold text-purple-700"><?php echo e(number_format($avgScoreChange, 1)); ?></div>
                            <div class="text-sm text-purple-600"><?php echo e(__('Avg Score Change')); ?></div>
                        </div>
                    </div>
                    
                    <!-- Progress Visualization -->
                    <div class="relative" style="height: 300px;">
                        <canvas id="progressChart"></canvas>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Detailed Student Progress -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Individual Student Progress')); ?></h4>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Student Name')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('School')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Baseline')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Latest')); ?> (<?php echo e(__('Cycle')); ?>)
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Level Change')); ?>

                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Score Change')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $progressData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo e($data['student']->name); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e($data['student']->school->school_name); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                            <?php echo e(__($data['baseline_level'])); ?>

                                        </span>
                                        <span class="text-xs text-gray-400">(<?php echo e($data['baseline_score']); ?>)</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                            <?php echo e(__($data['latest_level'])); ?>

                                        </span>
                                        <span class="text-xs text-gray-400">(<?php echo e($data['latest_score']); ?>) - <?php echo e(__(ucfirst($data['latest_cycle']))); ?></span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if($data['level_improved'] > 0): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                ↑ +<?php echo e($data['level_improved']); ?> <?php echo e(__('levels')); ?>

                                            </span>
                                        <?php elseif($data['level_improved'] < 0): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                ↓ <?php echo e($data['level_improved']); ?> <?php echo e(__('levels')); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                                = <?php echo e(__('Same level')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if($data['score_change'] > 0): ?>
                                            <span class="text-green-600 font-medium">+<?php echo e($data['score_change']); ?></span>
                                        <?php elseif($data['score_change'] < 0): ?>
                                            <span class="text-red-600 font-medium"><?php echo e($data['score_change']); ?></span>
                                        <?php else: ?>
                                            <span class="text-gray-500">0</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-4 text-center text-sm text-gray-500">
                                        <?php echo e(__('No students with multiple assessments found')); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
        <?php if(count($progressData) > 0): ?>
        $(document).ready(function() {
            const progressData = <?php echo json_encode($progressData, 15, 512) ?>;
            const levelChanges = progressData.reduce((acc, curr) => {
                const change = curr.level_improved;
                const key = change > 0 ? 'Improved' : (change < 0 ? 'Declined' : 'Maintained');
                acc[key] = (acc[key] || 0) + 1;
                return acc;
            }, {});
            
            // Create pie chart
            const ctx = document.getElementById('progressChart').getContext('2d');
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: Object.keys(levelChanges),
                    datasets: [{
                        data: Object.values(levelChanges),
                        backgroundColor: [
                            '#22c55e', // green for improved
                            '#ef4444', // red for declined
                            '#3b82f6'  // blue for maintained
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        title: {
                            display: true,
                            text: '<?php echo e(__("Student Progress Distribution")); ?>'
                        }
                    }
                }
            });
        });
        <?php endif; ?>
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/reports/progress-tracking.blade.php ENDPATH**/ ?>