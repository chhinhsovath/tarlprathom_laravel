<div class="max-w-4xl mx-auto">
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6">
            <h2 class="text-lg font-semibold mb-4">នាំចូលសិស្សពីឯកសារ CSV</h2>
            
            <!-- Download Template -->
            <div class="mb-6 p-4 bg-blue-50 rounded-lg">
                <p class="text-sm text-gray-700 mb-2">ទាញយកគំរូ CSV គំរូដើម្បីមើលទម្រង់ដែលរំពឹងទុក:</p>
                <button wire:click="downloadTemplate" class="text-sm text-blue-600 hover:text-blue-800 underline">
                    ទាញយកគំរូ CSV
                </button>
            </div>

            <form wire:submit.prevent="import">
                <!-- School Selection (Admin only) -->
                <?php if(auth()->user()->role === 'admin'): ?>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">ជ្រើសរើសសាលា</label>
                    <select wire:model="school_id" class="w-full rounded-md border-gray-300 shadow-sm">
                        <option value="">-- ជ្រើសរើសសាលា --</option>
                        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($school->id); ?>"><?php echo e($school->school_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php endif; ?>

                <!-- File Upload -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">ឯកសារ CSV</label>
                    <input type="file" wire:model="csvFile" accept=".csv,.txt" class="w-full">
                    <?php $__errorArgs = ['csvFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    <div wire:loading wire:target="csvFile" class="text-sm text-gray-500 mt-2">
                        កំពុងដំណើរការឯកសារ...
                    </div>
                </div>

                <!-- Field Mapping -->
                <?php if($showMapping): ?>
                <div class="mb-6 p-4 bg-gray-50 rounded-lg">
                    <h3 class="font-medium mb-3">ផ្គូផ្គងជួរដេញ CSV ទៅវាលសិស្ស</h3>
                    
                    <!-- Preview -->
                    <?php if(count($preview) > 0): ?>
                    <div class="mb-4 overflow-x-auto">
                        <p class="text-sm text-gray-600 mb-2">មើលជាមុន (៥ ជួរដំបូង):</p>
                        <table class="min-w-full text-sm border">
                            <thead>
                                <tr class="bg-gray-100">
                                    <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th class="border px-2 py-1"><?php echo e($header); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $preview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="border px-2 py-1"><?php echo e($cell); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>

                    <!-- Mapping Fields -->
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">ជួរដេញឈ្មោះ</label>
                            <select wire:model="mapping.name" class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm">
                                <option value="">-- ជ្រើសរើសជួរដេញ --</option>
                                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($header); ?>"><?php echo e($header); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['mapping.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">ជួរដេញភេទ</label>
                            <select wire:model="mapping.sex" class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm">
                                <option value="">-- ជ្រើសរើសជួរដេញ --</option>
                                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($header); ?>"><?php echo e($header); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['mapping.sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">ជួរដេញអាយុ</label>
                            <select wire:model="mapping.age" class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm">
                                <option value="">-- ជ្រើសរើសជួរដេញ --</option>
                                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($header); ?>"><?php echo e($header); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['mapping.age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">ជួរដេញថ្នាក់/កម្រិត</label>
                            <select wire:model="mapping.class" class="mt-1 w-full rounded-md border-gray-300 shadow-sm text-sm">
                                <option value="">-- ជ្រើសរើសជួរដេញ --</option>
                                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($header); ?>"><?php echo e($header); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['mapping.class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Import Errors -->
                <?php if(count($importErrors) > 0): ?>
                <div class="mb-4 p-4 bg-red-50 rounded-lg">
                    <h4 class="text-sm font-medium text-red-800 mb-2">កំហុសក្នុងការនាំចូល:</h4>
                    <ul class="text-sm text-red-700 list-disc list-inside max-h-40 overflow-y-auto">
                        <?php $__currentLoopData = $importErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Submit Button -->
                <div class="flex justify-end">
                    <button type="submit" 
                            <?php if(!$showMapping || !$school_id): ?> disabled <?php endif; ?>
                            class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed">
                        នាំចូលសិស្ស
                    </button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/livewire/csv-import.blade.php ENDPATH**/ ?>