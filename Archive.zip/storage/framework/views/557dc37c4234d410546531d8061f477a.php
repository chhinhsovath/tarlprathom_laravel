<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Class Details')); ?>

            </h2>
            <?php if(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('classes.edit', $class)); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                    </svg>
                    <?php echo e(__('Edit Class')); ?>

                </a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Class Information -->
                <div class="lg:col-span-1">
                    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                        <div class="p-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('Class Information')); ?></h3>
                            
                            <dl class="space-y-4">
                                <div>
                                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Class Name')); ?></dt>
                                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($class->name); ?></dd>
                                </div>
                                
                                <div>
                                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Grade Level')); ?></dt>
                                    <dd class="mt-1 text-sm text-gray-900"><?php echo e(__('Grade')); ?> <?php echo e($class->grade_level); ?></dd>
                                </div>
                                
                                <div>
                                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('School')); ?></dt>
                                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($class->school->name); ?></dd>
                                </div>
                                
                                <div>
                                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Teacher')); ?></dt>
                                    <dd class="mt-1 text-sm text-gray-900">
                                        <?php if($class->teacher): ?>
                                            <?php echo e($class->teacher->name); ?>

                                        <?php else: ?>
                                            <span class="text-gray-400"><?php echo e(__('Not Assigned')); ?></span>
                                        <?php endif; ?>
                                    </dd>
                                </div>
                                
                                <?php if($class->academic_year): ?>
                                    <div>
                                        <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Academic Year')); ?></dt>
                                        <dd class="mt-1 text-sm text-gray-900"><?php echo e($class->academic_year); ?></dd>
                                    </div>
                                <?php endif; ?>
                                
                                <div>
                                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Total Students')); ?></dt>
                                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($class->students->count()); ?></dd>
                                </div>
                                
                                <div>
                                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Status')); ?></dt>
                                    <dd class="mt-1">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($class->is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'); ?>">
                                            <?php echo e($class->is_active ? __('Active') : __('Inactive')); ?>

                                        </span>
                                    </dd>
                                </div>
                            </dl>
                        </div>
                    </div>
                </div>

                <!-- Students List -->
                <div class="lg:col-span-2">
                    <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                        <div class="p-6">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Students in this Class')); ?></h3>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Student::class)): ?>
                                    <a href="<?php echo e(route('students.create')); ?>?class_id=<?php echo e($class->id); ?>" class="inline-flex items-center px-3 py-1.5 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                        </svg>
                                        <?php echo e(__('Add Student')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>

                            <?php if($class->students->count() > 0): ?>
                                <div class="overflow-x-auto">
                                    <table class="min-w-full divide-y divide-gray-200">
                                        <thead class="bg-gray-50">
                                            <tr>
                                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Photo')); ?>

                                                </th>
                                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Name')); ?>

                                                </th>
                                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Gender')); ?>

                                                </th>
                                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Actions')); ?>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white divide-y divide-gray-200">
                                            <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="hover:bg-gray-50">
                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                        <div class="flex items-center">
                                                            <?php if($student->photo): ?>
                                                                <div class="h-10 w-10 flex-shrink-0 overflow-hidden rounded-full">
                                                                    <img src="<?php echo e(Storage::url($student->photo)); ?>" alt="<?php echo e($student->name); ?>" class="h-10 w-10 object-cover" style="height: 40px; width: 40px; object-fit: cover;">
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0">
                                                                    <svg class="h-6 w-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                                                    </svg>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                        <div class="text-sm font-medium text-gray-900">
                                                            <?php echo e($student->name); ?>

                                                        </div>
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                        <div class="text-sm text-gray-900"><?php echo e(ucfirst($student->gender)); ?></div>
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                        <a href="<?php echo e(route('students.show', $student)); ?>" class="text-indigo-600 hover:text-indigo-900 mr-3"><?php echo e(__('View')); ?></a>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $student)): ?>
                                                            <a href="<?php echo e(route('students.edit', $student)); ?>" class="text-indigo-600 hover:text-indigo-900"><?php echo e(__('Edit')); ?></a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-gray-500 text-center py-8"><?php echo e(__('No students in this class yet.')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/classes/show.blade.php ENDPATH**/ ?>