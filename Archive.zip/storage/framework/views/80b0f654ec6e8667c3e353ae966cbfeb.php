<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-6"><?php echo e(__('mentoring.Edit Mentoring Visit')); ?></h3>
                    
                    <form id="mentoringForm" method="POST" action="<?php echo e(route('mentoring.update', $mentoringVisit)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <!-- Progress Indicator -->
                        <div class="mb-8">
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-gray-600"><?php echo e(__('mentoring.Progress')); ?></span>
                                <span class="text-sm text-gray-600"><span id="progressPercent">0</span>%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2 mt-2">
                                <div id="progressBar" class="bg-blue-600 h-2 rounded-full transition-all duration-300" style="width: 0%"></div>
                            </div>
                        </div>

                        <!-- Section 1: Visit Details -->
                        <div class="questionnaire-section mb-8" data-section="visit_details">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('mentoring.Visit Details')); ?></h4>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Visit Date -->
                                <div>
                                    <label for="visit_date" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('mentoring.Visit Date')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <input type="date" 
                                           id="visit_date" 
                                           name="visit_date" 
                                           value="<?php echo e(old('visit_date', $mentoringVisit->visit_date->format('Y-m-d'))); ?>"
                                           class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                           required>
                                    <?php $__errorArgs = ['visit_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Region -->
                                <div>
                                    <label for="region" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('mentoring.Region')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" 
                                           id="region" 
                                           name="region" 
                                           value="<?php echo e(old('region', $mentoringVisit->region)); ?>"
                                           class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                           required>
                                    <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Province -->
                                <div>
                                    <label for="province" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('mentoring.Province')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="province" 
                                            name="province" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                            required>
                                        <option value=""><?php echo e(__('mentoring.Select Province')); ?></option>
                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($province); ?>" <?php echo e(old('province', $mentoringVisit->province) == $province ? 'selected' : ''); ?>>
                                                <?php echo e($province); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Mentor (for admin) -->
                                <?php if(auth()->user()->isAdmin()): ?>
                                <div>
                                    <label for="mentor_id" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('mentoring.Select Mentor')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="mentor_id" 
                                            name="mentor_id" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                            required>
                                        <option value=""><?php echo e(__('mentoring.Select Mentor')); ?></option>
                                        <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mentor->id); ?>" <?php echo e(old('mentor_id', $mentoringVisit->mentor_id) == $mentor->id ? 'selected' : ''); ?>>
                                                <?php echo e($mentor->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['mentor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php endif; ?>
                                
                                <!-- School -->
                                <div>
                                    <label for="school_id" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('School Name')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="school_id" 
                                            name="school_id" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                            required>
                                        <option value=""><?php echo e(__('Select School')); ?></option>
                                        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($school->id); ?>" <?php echo e(old('school_id', $mentoringVisit->school_id) == $school->id ? 'selected' : ''); ?>>
                                                <?php echo e($school->school_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Program Type -->
                                <div>
                                    <label for="program_type" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Program Type')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" 
                                           id="program_type" 
                                           name="program_type" 
                                           value="<?php echo e(old('program_type', $mentoringVisit->program_type ?? 'TaRL')); ?>"
                                           class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                           required>
                                    <?php $__errorArgs = ['program_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Section 2: Program Status -->
                        <div class="questionnaire-section mb-8" data-section="program_status">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Program Status')); ?></h4>
                            
                            <div class="space-y-6">
                                <!-- Class Taking Place -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Is the TaRL class taking place on the day of the visit?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="class_in_session" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>

                                                   required>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="class_in_session" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>

                                                   required>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['class_in_session'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Reason for Not Taking Place -->
                                <div id="notTakingPlaceReason" class="<?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'Yes' ? 'hidden' : ''); ?>">
                                    <label for="class_not_in_session_reason" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Why is the TaRL class not taking place?')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="class_not_in_session_reason" 
                                            name="class_not_in_session_reason" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                        <option value=""><?php echo e(__('Select Reason')); ?></option>
                                        <option value="Teacher is Absent" <?php echo e(old('class_not_in_session_reason', $mentoringVisit->class_not_in_session_reason) == 'Teacher is Absent' ? 'selected' : ''); ?>><?php echo e(__('Teacher is Absent')); ?></option>
                                        <option value="Most students are absent" <?php echo e(old('class_not_in_session_reason', $mentoringVisit->class_not_in_session_reason) == 'Most students are absent' ? 'selected' : ''); ?>><?php echo e(__('Most students are absent')); ?></option>
                                        <option value="The students have exams" <?php echo e(old('class_not_in_session_reason', $mentoringVisit->class_not_in_session_reason) == 'The students have exams' ? 'selected' : ''); ?>><?php echo e(__('The students have exams')); ?></option>
                                        <option value="The school has declared a holiday" <?php echo e(old('class_not_in_session_reason', $mentoringVisit->class_not_in_session_reason) == 'The school has declared a holiday' ? 'selected' : ''); ?>><?php echo e(__('The school has declared a holiday')); ?></option>
                                        <option value="Others" <?php echo e(old('class_not_in_session_reason', $mentoringVisit->class_not_in_session_reason) == 'Others' ? 'selected' : ''); ?>><?php echo e(__('Others')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['class_not_in_session_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Section 3: Teacher and Observation (shown only if class is in session) -->
                        <div id="observationSection" class="questionnaire-section mb-8 <?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'No' ? 'hidden' : ''); ?>" data-section="observation">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Teacher and Observation Details')); ?></h4>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Teacher -->
                                <div class="md:col-span-2">
                                    <label for="teacher_id" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Name of Teacher')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="teacher_id" 
                                            name="teacher_id" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                            required>
                                        <option value=""><?php echo e(__('Select Teacher')); ?></option>
                                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($teacher->id); ?>" 
                                                    data-school="<?php echo e($teacher->school_id); ?>"
                                                    <?php echo e(old('teacher_id', $mentoringVisit->teacher_id) == $teacher->id ? 'selected' : ''); ?>>
                                                <?php echo e($teacher->name); ?><?php echo e($teacher->school ? ' (' . $teacher->school->name . ')' : ''); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['teacher_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Full Session Observed -->
                                <div class="md:col-span-2">
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did you observe the full session?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="full_session_observed" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('full_session_observed', $mentoringVisit->full_session_observed ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="full_session_observed" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('full_session_observed', $mentoringVisit->full_session_observed ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['full_session_observed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Grade Group -->
                                <div>
                                    <label for="grade_group" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Grade Group')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="grade_group" 
                                            name="grade_group" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                        <option value=""><?php echo e(__('Select Grade Group')); ?></option>
                                        <option value="Std. 1-2" <?php echo e(old('grade_group', $mentoringVisit->grade_group) == 'Std. 1-2' ? 'selected' : ''); ?>><?php echo e(__('Std. 1-2')); ?></option>
                                        <option value="Std. 3-6" <?php echo e(old('grade_group', $mentoringVisit->grade_group) == 'Std. 3-6' ? 'selected' : ''); ?>><?php echo e(__('Std. 3-6')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['grade_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Grades Observed -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Grade(s) Observed')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="grid grid-cols-3 gap-2">
                                        <?php $__currentLoopData = ['1', '2', '3', '4', '5', '6']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center">
                                            <input type="checkbox" name="grades_observed[]" value="<?php echo e($grade); ?>" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(in_array($grade, old('grades_observed', $mentoringVisit->grades_observed ?? [])) ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Grade')); ?> <?php echo e($grade); ?></span>
                                        </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php $__errorArgs = ['grades_observed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Subject Observed -->
                                <div class="md:col-span-2">
                                    <label for="subject_observed" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Subject Observed')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="subject_observed" 
                                            name="subject_observed" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                        <option value=""><?php echo e(__('Select Subject')); ?></option>
                                        <option value="Language" <?php echo e(old('subject_observed', $mentoringVisit->subject_observed) == 'Language' ? 'selected' : ''); ?>><?php echo e(__('Language')); ?></option>
                                        <option value="Numeracy" <?php echo e(old('subject_observed', $mentoringVisit->subject_observed) == 'Numeracy' ? 'selected' : ''); ?>><?php echo e(__('Numeracy')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['subject_observed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Language Levels -->
                                <div id="languageLevelsDiv" class="md:col-span-2 <?php echo e(old('subject_observed', $mentoringVisit->subject_observed) != 'Language' ? 'hidden' : ''); ?>">
                                    <p class="text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('TaRL Level(s) observed (Language)')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                                        <?php $__currentLoopData = ['Beginner', 'Letter Level', 'Word', 'Paragraph', 'Story']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center">
                                            <input type="checkbox" name="language_levels_observed[]" value="<?php echo e($level); ?>" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(in_array($level, old('language_levels_observed', $mentoringVisit->language_levels_observed ?? [])) ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__($level)); ?></span>
                                        </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php $__errorArgs = ['language_levels_observed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Numeracy Levels -->
                                <div id="numeracyLevelsDiv" class="md:col-span-2 <?php echo e(old('subject_observed', $mentoringVisit->subject_observed) != 'Numeracy' ? 'hidden' : ''); ?>">
                                    <p class="text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('TaRL Level(s) observed (Numeracy)')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                                        <?php $__currentLoopData = ['Beginner', '1-Digit', '2-Digit', 'Subtraction', 'Division']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center">
                                            <input type="checkbox" name="numeracy_levels_observed[]" value="<?php echo e($level); ?>" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(in_array($level, old('numeracy_levels_observed', $mentoringVisit->numeracy_levels_observed ?? [])) ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__($level)); ?></span>
                                        </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php $__errorArgs = ['numeracy_levels_observed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Section 4: Delivery Questions (shown only if class is in session) -->
                        <div id="deliverySection" class="questionnaire-section mb-8 <?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'No' ? 'hidden' : ''); ?>" data-section="delivery">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Delivery Questions')); ?></h4>
                            
                            <div class="space-y-6">
                                <!-- Class Started on Time -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the class start on time (i.e. within 5 minutes of the scheduled time)?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="class_started_on_time" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('class_started_on_time', $mentoringVisit->class_started_on_time ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="class_started_on_time" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('class_started_on_time', $mentoringVisit->class_started_on_time ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['class_started_on_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Late Start Reason -->
                                <div id="lateStartReason" class="<?php echo e(old('class_started_on_time', $mentoringVisit->class_started_on_time ? 'Yes' : 'No') == 'Yes' ? 'hidden' : ''); ?>">
                                    <label for="late_start_reason" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('If no, then why did the class not start on time?')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="late_start_reason" 
                                            name="late_start_reason" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                        <option value=""><?php echo e(__('Select Reason')); ?></option>
                                        <option value="Teacher came late" <?php echo e(old('late_start_reason', $mentoringVisit->late_start_reason) == 'Teacher came late' ? 'selected' : ''); ?>><?php echo e(__('Teacher came late')); ?></option>
                                        <option value="Pupils came late" <?php echo e(old('late_start_reason', $mentoringVisit->late_start_reason) == 'Pupils came late' ? 'selected' : ''); ?>><?php echo e(__('Pupils came late')); ?></option>
                                        <option value="Others" <?php echo e(old('late_start_reason', $mentoringVisit->late_start_reason) == 'Others' ? 'selected' : ''); ?>><?php echo e(__('Others')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['late_start_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Section 5: Classroom Related Questions (shown only if class is in session) -->
                        <div id="classroomSection" class="questionnaire-section mb-8 <?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'No' ? 'hidden' : ''); ?>" data-section="classroom">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Classroom Related Questions')); ?></h4>
                            
                            <div class="space-y-6">
                                <!-- Materials Present -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Which materials did you see present in the classroom?')); ?>

                                    </p>
                                    <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                                        <?php $__currentLoopData = ['TaRL materials', 'Teaching aids', 'Student notebooks', 'Reading materials', 'Math manipulatives', 'Flash cards', 'Number charts', 'Letter charts', 'Story books', 'Activity sheets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="flex items-center">
                                            <input type="checkbox" name="materials_present[]" value="<?php echo e($material); ?>" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(in_array($material, old('materials_present', $mentoringVisit->materials_present ?? [])) ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__($material)); ?></span>
                                        </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php $__errorArgs = ['materials_present'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Children Grouped Appropriately -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Were the children grouped appropriately?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="children_grouped_appropriately" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('children_grouped_appropriately', $mentoringVisit->children_grouped_appropriately ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="children_grouped_appropriately" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('children_grouped_appropriately', $mentoringVisit->children_grouped_appropriately ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['children_grouped_appropriately'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Students Fully Involved -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Were the students fully involved in the activities?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="students_fully_involved" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('students_fully_involved', $mentoringVisit->students_fully_involved ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="students_fully_involved" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('students_fully_involved', $mentoringVisit->students_fully_involved ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['students_fully_involved'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Section 6: Teacher Related Questions (shown only if class is in session) -->
                        <div id="teacherSection" class="questionnaire-section mb-8 <?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'No' ? 'hidden' : ''); ?>" data-section="teacher">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Teacher Related Questions')); ?></h4>
                            
                            <div class="space-y-6">
                                <!-- Has Session Plan -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the teacher have a session plan?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="has_session_plan" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('has_session_plan', $mentoringVisit->has_session_plan ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="has_session_plan" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('has_session_plan', $mentoringVisit->has_session_plan ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['has_session_plan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- No Session Plan Reason -->
                                <div id="noSessionPlanReason" class="<?php echo e(old('has_session_plan', $mentoringVisit->has_session_plan ? 'Yes' : 'No') == 'Yes' ? 'hidden' : ''); ?>">
                                    <label for="no_session_plan_reason" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Why did the teacher not have a session plan?')); ?>

                                    </label>
                                    <textarea id="no_session_plan_reason" 
                                              name="no_session_plan_reason" 
                                              rows="3"
                                              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                              placeholder="<?php echo e(__('Describe the reason...')); ?>"><?php echo e(old('no_session_plan_reason', $mentoringVisit->no_session_plan_reason)); ?></textarea>
                                    <?php $__errorArgs = ['no_session_plan_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Followed Session Plan -->
                                <div id="followedSessionPlanDiv" class="<?php echo e(old('has_session_plan', $mentoringVisit->has_session_plan ? 'Yes' : 'No') == 'No' ? 'hidden' : ''); ?>">
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the teacher follow the session plan?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="followed_session_plan" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('followed_session_plan', $mentoringVisit->followed_session_plan ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="followed_session_plan" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('followed_session_plan', $mentoringVisit->followed_session_plan ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['followed_session_plan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- No Follow Plan Reason -->
                                <div id="noFollowPlanReason" class="<?php echo e(old('followed_session_plan', $mentoringVisit->followed_session_plan ? 'Yes' : 'No') == 'Yes' ? 'hidden' : ''); ?>">
                                    <label for="no_follow_plan_reason" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Why did the teacher not follow the session plan?')); ?>

                                    </label>
                                    <textarea id="no_follow_plan_reason" 
                                              name="no_follow_plan_reason" 
                                              rows="3"
                                              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                              placeholder="<?php echo e(__('Describe the reason...')); ?>"><?php echo e(old('no_follow_plan_reason', $mentoringVisit->no_follow_plan_reason)); ?></textarea>
                                    <?php $__errorArgs = ['no_follow_plan_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Session Plan Appropriate -->
                                <div id="sessionPlanAppropriateDiv" class="<?php echo e(old('has_session_plan', $mentoringVisit->has_session_plan ? 'Yes' : 'No') == 'No' ? 'hidden' : ''); ?>">
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Was the session plan appropriate for the children\'s learning level?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="session_plan_appropriate" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('session_plan_appropriate', $mentoringVisit->session_plan_appropriate ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="session_plan_appropriate" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('session_plan_appropriate', $mentoringVisit->session_plan_appropriate ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['session_plan_appropriate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Section 7: Activity Overview (shown only if class is in session) -->
                        <div id="activityOverviewSection" class="questionnaire-section mb-8 <?php echo e(old('class_in_session', $mentoringVisit->class_in_session ? 'Yes' : 'No') == 'No' ? 'hidden' : ''); ?>" data-section="activity_overview">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Activity Overview')); ?></h4>
                            
                            <div class="space-y-6">
                                <!-- Number of Activities -->
                                <div>
                                    <label for="number_of_activities" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('How many activities were conducted?')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="number_of_activities" 
                                            name="number_of_activities" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                        <option value=""><?php echo e(__('Select Number')); ?></option>
                                        <option value="1" <?php echo e(old('number_of_activities', $mentoringVisit->number_of_activities) == '1' ? 'selected' : ''); ?>><?php echo e(__('1')); ?></option>
                                        <option value="2" <?php echo e(old('number_of_activities', $mentoringVisit->number_of_activities) == '2' ? 'selected' : ''); ?>><?php echo e(__('2')); ?></option>
                                        <option value="3" <?php echo e(old('number_of_activities', $mentoringVisit->number_of_activities) == '3' ? 'selected' : ''); ?>><?php echo e(__('3')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['number_of_activities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Activity Sections - Will be shown based on number of activities and subject -->
                        <?php for($i = 1; $i <= 3; $i++): ?>
                        <div id="activity<?php echo e($i); ?>Section" class="questionnaire-section mb-8 hidden" data-section="activity_<?php echo e($i); ?>">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Activity')); ?> <?php echo e($i); ?> <?php echo e(__('Details')); ?></h4>
                            
                            <div class="space-y-6">
                                <!-- Activity Name (Language) -->
                                <div id="activity<?php echo e($i); ?>LanguageDiv" class="hidden">
                                    <label for="activity<?php echo e($i); ?>_name_language" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Which was the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity conducted? (Language)')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="activity<?php echo e($i); ?>_name_language" 
                                            name="activity<?php echo e($i); ?>_name_language" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                        <option value=""><?php echo e(__('Select Activity')); ?></option>
                                        <?php $__currentLoopData = ['Letter recognition', 'Letter writing', 'Word building', 'Word reading', 'Sentence reading', 'Story reading', 'Comprehension activities', 'Vocabulary games', 'Phonics activities', 'Others']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($activity); ?>" <?php echo e(old('activity'.$i.'_name_language', $mentoringVisit->{'activity'.$i.'_name_language'}) == $activity ? 'selected' : ''); ?>><?php echo e(__($activity)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_name_language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Activity Name (Numeracy) -->
                                <div id="activity<?php echo e($i); ?>NumeracyDiv" class="hidden">
                                    <label for="activity<?php echo e($i); ?>_name_numeracy" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Which was the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity conducted? (Numeracy)')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <select id="activity<?php echo e($i); ?>_name_numeracy" 
                                            name="activity<?php echo e($i); ?>_name_numeracy" 
                                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                        <option value=""><?php echo e(__('Select Activity')); ?></option>
                                        <?php $__currentLoopData = ['Number chart reading activity', 'Recognition of the numbers with symbol and objects', 'Puzzles', 'Number Jump', 'Basket game', 'Clap and Snap', 'What next - Count Before / Count After', 'Number line - Counting and find the numbers move to left and move to right', 'Fine with Nine', 'Place value - Bundle and sticks with numbers up to 20', 'Making bundles and counting 10, 20, 30, 40, …', 'Learning two digit numbers with bundle and sticks', 'Addition of single digit numbers with sticks and without any material by using frame and word problems', 'Subtraction of single digit numbers with sticks and without any material, by using and word problems', 'Word problem of two digit number of addition and subtraction without any material', 'Who is my third partner - with numbers 1 to 9']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($activity); ?>" <?php echo e(old('activity'.$i.'_name_numeracy', $mentoringVisit->{'activity'.$i.'_name_numeracy'}) == $activity ? 'selected' : ''); ?>><?php echo e(__($activity)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_name_numeracy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Activity Duration -->
                                <div>
                                    <label for="activity<?php echo e($i); ?>_duration" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('What was the duration of the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity? (Mins)')); ?> <span class="text-red-500">*</span>
                                    </label>
                                    <input type="number" 
                                           id="activity<?php echo e($i); ?>_duration" 
                                           name="activity<?php echo e($i); ?>_duration" 
                                           value="<?php echo e(old('activity'.$i.'_duration', $mentoringVisit->{'activity'.$i.'_duration'})); ?>"
                                           min="1"
                                           class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Clear Instructions -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the teacher give clear instructions for the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_clear_instructions" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_clear_instructions', $mentoringVisit->{'activity'.$i.'_clear_instructions'} ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_clear_instructions" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_clear_instructions', $mentoringVisit->{'activity'.$i.'_clear_instructions'} ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_clear_instructions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- No Clear Instructions Reason -->
                                <div id="activity<?php echo e($i); ?>NoInstructionsReason" class="<?php echo e(old('activity'.$i.'_clear_instructions', $mentoringVisit->{'activity'.$i.'_clear_instructions'} ? 'Yes' : 'No') == 'Yes' ? 'hidden' : ''); ?>">
                                    <label for="activity<?php echo e($i); ?>_no_clear_instructions_reason" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Why did the teacher not give clear instructions for the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity?')); ?>

                                    </label>
                                    <textarea id="activity<?php echo e($i); ?>_no_clear_instructions_reason" 
                                              name="activity<?php echo e($i); ?>_no_clear_instructions_reason" 
                                              rows="3"
                                              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                              placeholder="<?php echo e(__('Describe the reason...')); ?>"><?php echo e(old('activity'.$i.'_no_clear_instructions_reason', $mentoringVisit->{'activity'.$i.'_no_clear_instructions_reason'})); ?></textarea>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_no_clear_instructions_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Activity Demonstrated -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the teacher demonstrate the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_demonstrated" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_demonstrated', $mentoringVisit->{'activity'.$i.'_demonstrated'} ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_demonstrated" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_demonstrated', $mentoringVisit->{'activity'.$i.'_demonstrated'} ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_demonstrated'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Students Practice -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the teacher make a few students practice the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity in front of the whole class?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_students_practice" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_students_practice', $mentoringVisit->{'activity'.$i.'_students_practice'}) == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_students_practice" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_students_practice', $mentoringVisit->{'activity'.$i.'_students_practice'}) == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_students_practice" value="Not applicable" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_students_practice', $mentoringVisit->{'activity'.$i.'_students_practice'}) == 'Not applicable' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Not applicable')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_students_practice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Small Groups -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the students perform the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity in small groups?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_small_groups" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_small_groups', $mentoringVisit->{'activity'.$i.'_small_groups'}) == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_small_groups" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_small_groups', $mentoringVisit->{'activity'.$i.'_small_groups'}) == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_small_groups" value="Not Applicable" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_small_groups', $mentoringVisit->{'activity'.$i.'_small_groups'}) == 'Not Applicable' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Not Applicable')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_small_groups'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Individual -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Did the students individually perform the')); ?> <?php echo e($i == 1 ? __('first') : ($i == 2 ? __('second') : __('third'))); ?> <?php echo e(__('activity?')); ?> <span class="text-red-500">*</span>
                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_individual" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_individual', $mentoringVisit->{'activity'.$i.'_individual'}) == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_individual" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_individual', $mentoringVisit->{'activity'.$i.'_individual'}) == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="activity<?php echo e($i); ?>_individual" value="Not Applicable" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('activity'.$i.'_individual', $mentoringVisit->{'activity'.$i.'_individual'}) == 'Not Applicable' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Not Applicable')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['activity<?php echo e($i); ?>_individual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <?php endfor; ?>

                        <!-- Section 8: Additional Observations -->
                        <div class="questionnaire-section mb-8" data-section="additional">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b"><?php echo e(__('Additional Observations')); ?></h4>
                            
                            <div class="space-y-6">
                                <!-- General Observations -->
                                <div>
                                    <label for="observation" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('General Observations')); ?>

                                    </label>
                                    <textarea id="observation" 
                                              name="observation" 
                                              rows="4"
                                              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                              placeholder="<?php echo e(__('Describe your observations from the visit...')); ?>"><?php echo e(old('observation', $mentoringVisit->observation)); ?></textarea>
                                    <?php $__errorArgs = ['observation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Action Plan -->
                                <div>
                                    <label for="action_plan" class="block text-sm font-medium text-gray-700 mb-2">
                                        <?php echo e(__('Action Plan')); ?>

                                    </label>
                                    <textarea id="action_plan" 
                                              name="action_plan" 
                                              rows="4"
                                              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                              placeholder="<?php echo e(__('Describe recommended actions and next steps...')); ?>"><?php echo e(old('action_plan', $mentoringVisit->action_plan)); ?></textarea>
                                    <?php $__errorArgs = ['action_plan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <!-- Follow-up Required -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-3">
                                        <?php echo e(__('Is follow-up required?')); ?>

                                    </p>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="follow_up_required" value="Yes" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('follow_up_required', $mentoringVisit->follow_up_required ? 'Yes' : 'No') == 'Yes' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('Yes')); ?></span>
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="follow_up_required" value="No" 
                                                   class="mr-2 text-indigo-600 focus:ring-indigo-500"
                                                   <?php echo e(old('follow_up_required', $mentoringVisit->follow_up_required ? 'Yes' : 'No') == 'No' ? 'checked' : ''); ?>>
                                            <span class="text-sm text-gray-700"><?php echo e(__('No')); ?></span>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['follow_up_required'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="flex items-center justify-between pt-6 border-t">
                            <a href="<?php echo e(route('mentoring.index')); ?>" 
                               class="inline-flex items-center px-4 py-2 bg-gray-300 border border-transparent rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-400 focus:bg-gray-400 active:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                <?php echo e(__('Cancel')); ?>

                            </a>
                            
                            <button type="submit" 
                                    class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                </svg>
                                <?php echo e(__('Update Visit Report')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // School-Teacher filtering
            const schoolSelect = document.getElementById('school_id');
            const teacherSelect = document.getElementById('teacher_id');
            const teacherOptions = Array.from(teacherSelect.options);
            
            function filterTeachers() {
                const selectedSchoolId = schoolSelect.value;
                const currentSelection = teacherSelect.value;
                teacherSelect.innerHTML = '<option value=""><?php echo e(__("Select Teacher")); ?></option>';
                
                teacherOptions.forEach(option => {
                    if (option.value) {
                        // Show teacher if no school is selected, or if teacher's school matches, or if teacher has no school assigned
                        if (!selectedSchoolId || 
                            option.dataset.school == selectedSchoolId || 
                            !option.dataset.school || 
                            option.dataset.school === '') {
                            const newOption = option.cloneNode(true);
                            if (newOption.value == currentSelection) {
                                newOption.selected = true;
                            }
                            teacherSelect.appendChild(newOption);
                        }
                    }
                });
            }
            
            schoolSelect.addEventListener('change', filterTeachers);
            
            // Class in session logic
            const classInSessionRadios = document.getElementsByName('class_in_session');
            const notTakingPlaceReason = document.getElementById('notTakingPlaceReason');
            const observationSection = document.getElementById('observationSection');
            
            function toggleClassSections() {
                const isInSession = document.querySelector('input[name="class_in_session"]:checked')?.value === 'Yes';
                
                if (isInSession) {
                    notTakingPlaceReason.classList.add('hidden');
                    observationSection.classList.remove('hidden');
                    document.getElementById('class_not_in_session_reason').removeAttribute('required');
                } else {
                    notTakingPlaceReason.classList.remove('hidden');
                    observationSection.classList.add('hidden');
                    document.getElementById('class_not_in_session_reason').setAttribute('required', 'required');
                }
                
                updateProgress();
            }
            
            classInSessionRadios.forEach(radio => {
                radio.addEventListener('change', toggleClassSections);
            });
            
            function toggleClassSessionSections() {
                const isInSession = document.querySelector('input[name="class_in_session"]:checked')?.value === 'Yes';
                const deliverySection = document.getElementById('deliverySection');
                const classroomSection = document.getElementById('classroomSection');
                const teacherSection = document.getElementById('teacherSection');
                const activityOverviewSection = document.getElementById('activityOverviewSection');
                
                if (isInSession) {
                    deliverySection.classList.remove('hidden');
                    classroomSection.classList.remove('hidden');
                    teacherSection.classList.remove('hidden');
                    activityOverviewSection.classList.remove('hidden');
                } else {
                    deliverySection.classList.add('hidden');
                    classroomSection.classList.add('hidden');
                    teacherSection.classList.add('hidden');
                    activityOverviewSection.classList.add('hidden');
                }
                updateProgress();
            }
            
            classInSessionRadios.forEach(radio => {
                radio.addEventListener('change', toggleClassSessionSections);
            });
            
            // Class start time logic
            const classStartedRadios = document.getElementsByName('class_started_on_time');
            const lateStartReason = document.getElementById('lateStartReason');
            
            function toggleLateStartReason() {
                const startedOnTime = document.querySelector('input[name="class_started_on_time"]:checked')?.value === 'Yes';
                if (startedOnTime) {
                    lateStartReason.classList.add('hidden');
                    document.getElementById('late_start_reason').removeAttribute('required');
                } else {
                    lateStartReason.classList.remove('hidden');
                    document.getElementById('late_start_reason').setAttribute('required', 'required');
                }
                updateProgress();
            }
            
            classStartedRadios.forEach(radio => {
                radio.addEventListener('change', toggleLateStartReason);
            });
            
            // Session plan logic
            const sessionPlanRadios = document.getElementsByName('has_session_plan');
            const noSessionPlanReason = document.getElementById('noSessionPlanReason');
            const followedSessionPlanDiv = document.getElementById('followedSessionPlanDiv');
            const sessionPlanAppropriateDiv = document.getElementById('sessionPlanAppropriateDiv');
            
            function toggleSessionPlanSections() {
                const hasSessionPlan = document.querySelector('input[name="has_session_plan"]:checked')?.value === 'Yes';
                
                if (hasSessionPlan) {
                    noSessionPlanReason.classList.add('hidden');
                    followedSessionPlanDiv.classList.remove('hidden');
                    sessionPlanAppropriateDiv.classList.remove('hidden');
                } else {
                    noSessionPlanReason.classList.remove('hidden');
                    followedSessionPlanDiv.classList.add('hidden');
                    sessionPlanAppropriateDiv.classList.add('hidden');
                }
                updateProgress();
            }
            
            sessionPlanRadios.forEach(radio => {
                radio.addEventListener('change', toggleSessionPlanSections);
            });
            
            // Followed session plan logic
            const followedPlanRadios = document.getElementsByName('followed_session_plan');
            const noFollowPlanReason = document.getElementById('noFollowPlanReason');
            
            function toggleFollowPlanReason() {
                const followedPlan = document.querySelector('input[name="followed_session_plan"]:checked')?.value === 'Yes';
                if (followedPlan) {
                    noFollowPlanReason.classList.add('hidden');
                } else {
                    noFollowPlanReason.classList.remove('hidden');
                }
                updateProgress();
            }
            
            followedPlanRadios.forEach(radio => {
                radio.addEventListener('change', toggleFollowPlanReason);
            });
            
            // Activity clear instructions logic
            for (let i = 1; i <= 3; i++) {
                const clearInstructionsRadios = document.getElementsByName('activity' + i + '_clear_instructions');
                const noInstructionsReason = document.getElementById('activity' + i + 'NoInstructionsReason');
                
                function toggleInstructionsReason() {
                    const clearInstructions = document.querySelector('input[name="activity' + i + '_clear_instructions"]:checked')?.value === 'Yes';
                    if (clearInstructions) {
                        noInstructionsReason.classList.add('hidden');
                    } else {
                        noInstructionsReason.classList.remove('hidden');
                    }
                    updateProgress();
                }
                
                clearInstructionsRadios.forEach(radio => {
                    radio.addEventListener('change', toggleInstructionsReason);
                });
            }
            
            // Subject levels logic
            const subjectSelect = document.getElementById('subject_observed');
            const languageLevelsDiv = document.getElementById('languageLevelsDiv');
            const numeracyLevelsDiv = document.getElementById('numeracyLevelsDiv');
            
            function toggleSubjectLevels() {
                const selectedSubject = subjectSelect.value;
                
                if (selectedSubject === 'Language') {
                    languageLevelsDiv.classList.remove('hidden');
                    numeracyLevelsDiv.classList.add('hidden');
                } else if (selectedSubject === 'Numeracy') {
                    languageLevelsDiv.classList.add('hidden');
                    numeracyLevelsDiv.classList.remove('hidden');
                } else {
                    languageLevelsDiv.classList.add('hidden');
                    numeracyLevelsDiv.classList.add('hidden');
                }
                
                // Also toggle activity name sections
                toggleActivitySections();
                updateProgress();
            }
            
            subjectSelect.addEventListener('change', toggleSubjectLevels);
            
            // Number of activities logic
            const activitiesSelect = document.getElementById('number_of_activities');
            
            function toggleActivitySections() {
                const numberOfActivities = parseInt(activitiesSelect.value) || 0;
                const selectedSubject = subjectSelect.value;
                
                for (let i = 1; i <= 3; i++) {
                    const activitySection = document.getElementById('activity' + i + 'Section');
                    const languageDiv = document.getElementById('activity' + i + 'LanguageDiv');
                    const numeracyDiv = document.getElementById('activity' + i + 'NumeracyDiv');
                    
                    if (i <= numberOfActivities) {
                        activitySection.classList.remove('hidden');
                        
                        if (selectedSubject === 'Language') {
                            languageDiv.classList.remove('hidden');
                            numeracyDiv.classList.add('hidden');
                        } else if (selectedSubject === 'Numeracy') {
                            languageDiv.classList.add('hidden');
                            numeracyDiv.classList.remove('hidden');
                        } else {
                            languageDiv.classList.add('hidden');
                            numeracyDiv.classList.add('hidden');
                        }
                    } else {
                        activitySection.classList.add('hidden');
                        languageDiv.classList.add('hidden');
                        numeracyDiv.classList.add('hidden');
                    }
                }
                updateProgress();
            }
            
            activitiesSelect.addEventListener('change', toggleActivitySections);
            
            // Progress tracking
            function updateProgress() {
                const requiredFields = document.querySelectorAll('[required]:not([type="hidden"])');
                const filledFields = Array.from(requiredFields).filter(field => {
                    if (field.type === 'checkbox' || field.type === 'radio') {
                        return document.querySelector(`[name="${field.name}"]:checked`);
                    }
                    return field.value.trim() !== '';
                });
                
                const progress = Math.round((filledFields.length / requiredFields.length) * 100);
                document.getElementById('progressPercent').textContent = progress;
                document.getElementById('progressBar').style.width = progress + '%';
            }
            
            // Add progress tracking to all inputs
            document.querySelectorAll('input, select, textarea').forEach(element => {
                element.addEventListener('change', updateProgress);
                element.addEventListener('input', updateProgress);
            });
            
            // Initialize
            filterTeachers();
            toggleClassSections();
            toggleClassSessionSections();
            toggleLateStartReason();
            toggleSessionPlanSections();
            toggleFollowPlanReason();
            toggleSubjectLevels();
            toggleActivitySections();
            updateProgress();
        });
        
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/mentoring/edit.blade.php ENDPATH**/ ?>