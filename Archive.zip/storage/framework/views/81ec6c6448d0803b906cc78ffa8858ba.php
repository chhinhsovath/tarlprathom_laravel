<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <!-- Header -->
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Mentoring Visit Details')); ?></h3>
                        <a href="<?php echo e(route('mentoring.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                            ← <?php echo e(__('Back to list')); ?>

                        </a>
                    </div>

                    <!-- Visit Details -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h4 class="text-sm font-medium text-gray-500"><?php echo e(__('Visit Date')); ?></h4>
                            <p class="mt-1 text-sm text-gray-900"><?php echo e($mentoringVisit->visit_date->format('Y-m-d')); ?></p>
                        </div>
                        
                        <div>
                            <h4 class="text-sm font-medium text-gray-500"><?php echo e(__('Score')); ?></h4>
                            <p class="mt-1">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium 
                                    <?php if($mentoringVisit->score >= 80): ?> bg-green-100 text-green-800
                                    <?php elseif($mentoringVisit->score >= 60): ?> bg-yellow-100 text-yellow-800
                                    <?php else: ?> bg-red-100 text-red-800
                                    <?php endif; ?>">
                                    <?php echo e($mentoringVisit->score); ?>%
                                </span>
                            </p>
                        </div>
                        
                        <div>
                            <h4 class="text-sm font-medium text-gray-500"><?php echo e(__('School')); ?></h4>
                            <p class="mt-1 text-sm text-gray-900"><?php echo e($mentoringVisit->school->school_name); ?></p>
                        </div>
                        
                        <div>
                            <h4 class="text-sm font-medium text-gray-500"><?php echo e(__('Teacher')); ?></h4>
                            <p class="mt-1 text-sm text-gray-900"><?php echo e($mentoringVisit->teacher->name); ?></p>
                        </div>
                        
                        <div>
                            <h4 class="text-sm font-medium text-gray-500"><?php echo e(__('Mentor')); ?></h4>
                            <p class="mt-1 text-sm text-gray-900"><?php echo e($mentoringVisit->mentor->name); ?></p>
                        </div>
                    </div>
                    
                    <div class="mt-6">
                        <h4 class="text-sm font-medium text-gray-500"><?php echo e(__('Observation Notes')); ?></h4>
                        <p class="mt-1 text-sm text-gray-900 whitespace-pre-wrap"><?php echo e($mentoringVisit->observation); ?></p>
                    </div>
                    
                    <?php if($mentoringVisit->photo): ?>
                    <div class="mt-6">
                        <h4 class="text-sm font-medium text-gray-500 mb-2"><?php echo e(__('Photo')); ?></h4>
                        <img src="<?php echo e(Storage::url($mentoringVisit->photo)); ?>" 
                             alt="Visit photo" 
                             class="max-w-full h-auto rounded-lg shadow-md"
                             style="max-height: 400px;">
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/mentoring/show.blade.php ENDPATH**/ ?>