<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                <div class="p-6">
                    <h1 class="text-2xl font-bold mb-4">Translation Test</h1>
                    
                    <div class="space-y-2">
                        <p><strong>Locale:</strong> <?php echo e(app()->getLocale()); ?></p>
                        <p><strong>Session Locale:</strong> <?php echo e(session('locale')); ?></p>
                        <p><strong>Lang Path:</strong> <?php echo e(app()->langPath()); ?></p>
                    </div>
                    
                    <h2 class="text-xl font-semibold mt-6 mb-4">Translation Tests:</h2>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-4 py-2 text-left">Key</th>
                                <th class="px-4 py-2 text-left">Translation</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <tr>
                                <td class="px-4 py-2">Bulk Import Students</td>
                                <td class="px-4 py-2"><?php echo e(__('Bulk Import Students')); ?></td>
                            </tr>
                            <tr>
                                <td class="px-4 py-2">Instructions</td>
                                <td class="px-4 py-2"><?php echo e(__('Instructions')); ?></td>
                            </tr>
                            <tr>
                                <td class="px-4 py-2">Download Excel Template</td>
                                <td class="px-4 py-2"><?php echo e(__('Download Excel Template')); ?></td>
                            </tr>
                            <tr>
                                <td class="px-4 py-2"><?php echo e(__("Name")); ?></td>
                                <td class="px-4 py-2"><?php echo e(__('Name')); ?></td>
                            </tr>
                            <tr>
                                <td class="px-4 py-2">Age</td>
                                <td class="px-4 py-2"><?php echo e(__('Age')); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/test-translation.blade.php ENDPATH**/ ?>