<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
            <h2 class="font-semibold text-lg sm:text-xl text-gray-800 leading-tight">
                <?php echo e(__('Student Details')); ?>

            </h2>
            <div class="flex gap-2">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $student)): ?>
                    <a href="<?php echo e(route('students.edit', $student)); ?>" class="inline-flex items-center px-3 py-1.5 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                        </svg>
                        <?php echo e(__('Edit')); ?>

                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('students.index')); ?>" class="inline-flex items-center px-3 py-1.5 bg-gray-300 border border-transparent rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-400 focus:bg-gray-400 active:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition ease-in-out duration-150">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16l-4-4m0 0l4-4m-4 4h18"></path>
                    </svg>
                    <?php echo e(__('Back')); ?>

                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Student Info Card -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mb-6">
                <div class="p-4 sm:p-6">
                    <div class="flex flex-col sm:flex-row gap-4 sm:gap-6">
                        <!-- Photo Section -->
                        <div class="flex-shrink-0">
                            <?php if($student->photo): ?>
                                <div class="h-16 w-16 rounded-lg overflow-hidden shadow-md">
                                    <img src="<?php echo e(Storage::url($student->photo)); ?>" alt="<?php echo e($student->name); ?>" class="h-full w-full object-cover" style="height: 64px; width: 64px; object-fit: cover;">
                                </div>
                            <?php else: ?>
                                <div class="h-16 w-16 rounded-lg bg-gray-200 flex items-center justify-center">
                                    <svg class="h-10 w-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                    </svg>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Student Details -->
                        <div class="flex-grow">
                            <h3 class="text-lg font-semibold text-gray-900 mb-3"><?php echo e($student->name); ?></h3>
                            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                                <div>
                                    <span class="text-xs text-gray-500 uppercase tracking-wider"><?php echo e(__('Grade')); ?></span>
                                    <p class="text-sm font-medium text-gray-900"><?php echo e(__('Grade')); ?> <?php echo e($student->grade); ?></p>
                                </div>
                                <div>
                                    <span class="text-xs text-gray-500 uppercase tracking-wider"><?php echo e(__('Gender')); ?></span>
                                    <p class="text-sm font-medium text-gray-900"><?php echo e(ucfirst($student->gender)); ?></p>
                                </div>
                                <div class="col-span-2 sm:col-span-1 lg:col-span-2">
                                    <span class="text-xs text-gray-500 uppercase tracking-wider"><?php echo e(__('School')); ?></span>
                                    <p class="text-sm font-medium text-gray-900"><?php echo e($student->school->school_name ?? 'N/A'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <?php if($student->assessments->count() > 0): ?>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                    <?php
                        $mathScores = $student->assessments->where('subject', 'math')->pluck('score');
                        $khmerScores = $student->assessments->where('subject', 'khmer')->pluck('score');
                        $latestAssessment = $student->assessments->sortByDesc('assessed_at')->first();
                    ?>
                    
                    <div class="bg-white rounded-lg shadow-sm p-4">
                        <p class="text-xs text-gray-500 uppercase"><?php echo e(__('Total Assessments')); ?></p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo e($student->assessments->count()); ?></p>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow-sm p-4">
                        <p class="text-xs text-gray-500 uppercase"><?php echo e(__('Avg Math Score')); ?></p>
                        <p class="text-2xl font-semibold text-gray-900">
                            <?php echo e($mathScores->count() > 0 ? round($mathScores->avg()) : '-'); ?>%
                        </p>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow-sm p-4">
                        <p class="text-xs text-gray-500 uppercase"><?php echo e(__('Avg Khmer Score')); ?></p>
                        <p class="text-2xl font-semibold text-gray-900">
                            <?php echo e($khmerScores->count() > 0 ? round($khmerScores->avg()) : '-'); ?>%
                        </p>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow-sm p-4">
                        <p class="text-xs text-gray-500 uppercase"><?php echo e(__('Latest Assessment')); ?></p>
                        <p class="text-sm font-semibold text-gray-900">
                            <?php echo e($latestAssessment && $latestAssessment->assessed_at ? $latestAssessment->assessed_at->format('M d, Y') : '-'); ?>

                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Assessment History Card -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                <div class="p-4 sm:p-6">
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                        <h3 class="text-lg font-semibold text-gray-900"><?php echo e(__('Assessment History')); ?></h3>
                        <?php if($student->assessments->count() > 0): ?>
                            <span class="text-sm text-gray-500 mt-1 sm:mt-0">
                                <?php echo e($student->assessments->count()); ?> <?php echo e(__('assessment(s)')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if($student->assessments->count() > 0): ?>
                        <!-- Mobile View -->
                        <div class="sm:hidden space-y-3">
                            <?php $__currentLoopData = $student->assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border rounded-lg p-3 bg-gray-50">
                                    <div class="flex justify-between items-start mb-2">
                                        <div>
                                            <p class="text-sm font-medium text-gray-900"><?php echo e(ucfirst($assessment->subject)); ?></p>
                                            <p class="text-xs text-gray-500"><?php echo e($assessment->assessed_at ? $assessment->assessed_at->format('M d, Y') : 'N/A'); ?></p>
                                        </div>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                            <?php echo e($assessment->score); ?>%
                                        </span>
                                    </div>
                                    <div class="grid grid-cols-2 gap-2 text-xs">
                                        <div>
                                            <span class="text-gray-500"><?php echo e(__('Cycle:')); ?></span>
                                            <span class="text-gray-900 ml-1"><?php echo e(ucfirst($assessment->cycle)); ?></span>
                                        </div>
                                        <div>
                                            <span class="text-gray-500"><?php echo e(__('Level:')); ?></span>
                                            <span class="text-gray-900 ml-1"><?php echo e($assessment->level); ?></span>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <a href="<?php echo e(route('assessments.show', $assessment)); ?>" class="text-xs text-indigo-600 hover:text-indigo-900">
                                            <?php echo e(__('View Details')); ?> →
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <!-- Desktop/Tablet View -->
                        <div class="hidden sm:block overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Date')); ?>

                                        </th>
                                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Cycle')); ?>

                                        </th>
                                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Subject')); ?>

                                        </th>
                                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Level')); ?>

                                        </th>
                                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Score')); ?>

                                        </th>
                                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Actions')); ?>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $student->assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <?php echo e($assessment->assessed_at ? $assessment->assessed_at->format('M d, Y') : 'N/A'); ?>

                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm">
                                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium 
                                                    <?php echo e($assessment->cycle == 'baseline' ? 'bg-gray-100 text-gray-800' : ''); ?>

                                                    <?php echo e($assessment->cycle == 'midline' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                                    <?php echo e($assessment->cycle == 'endline' ? 'bg-green-100 text-green-800' : ''); ?>">
                                                    <?php echo e(ucfirst($assessment->cycle)); ?>

                                                </span>
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <?php echo e(ucfirst($assessment->subject)); ?>

                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <?php echo e($assessment->level); ?>

                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm">
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                    <?php echo e($assessment->score); ?>%
                                                </span>
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm font-medium">
                                                <a href="<?php echo e(route('assessments.show', $assessment)); ?>" class="text-indigo-600 hover:text-indigo-900">
                                                    <?php echo e(__('View')); ?>

                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-8">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                            <p class="mt-2 text-sm text-gray-500"><?php echo e(__('No assessments found for this student.')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/students/show.blade.php ENDPATH**/ ?>