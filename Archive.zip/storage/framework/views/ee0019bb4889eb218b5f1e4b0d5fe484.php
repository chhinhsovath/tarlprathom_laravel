<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* Sticky table styles */
        .sticky {
            position: sticky !important;
        }
        
        /* Ensure sticky row stays on top */
        thead tr.sticky {
            position: sticky !important;
            top: 0 !important;
            z-index: 20 !important;
        }
        
        /* Add shadow to sticky row */
        thead tr.sticky {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        /* Style for sticky name column */
        .sticky.left-0 {
            box-shadow: 2px 0 4px rgba(0,0,0,0.1);
        }
        
        /* Ensure proper z-index layering */
        thead th.sticky.left-0 {
            z-index: 30 !important;
        }
        
        /* Style for saved rows */
        .student-row[data-saved="true"] td.sticky {
            background-color: #f0fdf4;
        }
        
        /* Add scroll indicators */
        .table-container {
            position: relative;
        }
        
        .table-container::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 40px;
            background: linear-gradient(to top, rgba(255,255,255,1), rgba(255,255,255,0));
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .table-container.scrollable::after {
            opacity: 1;
        }
    </style>

    <div class="py-6">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    
                    <!-- Subject and Cycle Selection -->
                    <div class="mb-6 flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Subject')); ?>:</label>
                                <select id="subject" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                    <option value="khmer" <?php echo e($subject === 'khmer' ? 'selected' : ''); ?>><?php echo e(__('Khmer')); ?></option>
                                    <option value="math" <?php echo e($subject === 'math' ? 'selected' : ''); ?>><?php echo e(__('Math')); ?></option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Test Cycle')); ?>:</label>
                                <select id="cycle" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                    <option value="baseline" <?php echo e($cycle === 'baseline' ? 'selected' : ''); ?>><?php echo e(__('Baseline')); ?></option>
                                    <option value="midline" <?php echo e($cycle === 'midline' ? 'selected' : ''); ?>><?php echo e(__('Midline')); ?></option>
                                    <option value="endline" <?php echo e($cycle === 'endline' ? 'selected' : ''); ?>><?php echo e(__('Endline')); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="text-sm text-gray-600">
                            <span id="savedCount">0</span> / <span id="totalCount"><?php echo e(count($students)); ?></span> <?php echo e(__('students assessed')); ?>

                        </div>
                    </div>

                    <!-- Assessment Period Notice -->
                    <?php if(auth()->user()->school && !auth()->user()->isAdmin()): ?>
                        <?php
                            $school = auth()->user()->school;
                            $periodStatus = $school->getAssessmentPeriodStatus($cycle);
                        ?>
                        
                        <?php if($periodStatus === 'not_set'): ?>
                            <div class="mb-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
                                <div class="flex">
                                    <div class="flex-shrink-0">
                                        <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm text-yellow-700">
                                            <?php echo e(__('Assessment dates have not been set for your school. Please contact your administrator.')); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php elseif($periodStatus === 'upcoming'): ?>
                            <div class="mb-4 bg-blue-50 border-l-4 border-blue-400 p-4">
                                <div class="flex">
                                    <div class="flex-shrink-0">
                                        <svg class="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm text-blue-700">
                                            <?php if($cycle === 'baseline'): ?>
                                                <?php echo e(__('Baseline assessment period starts on')); ?> <?php echo e($school->baseline_start_date->format('d/m/Y')); ?>.
                                            <?php elseif($cycle === 'midline'): ?>
                                                <?php echo e(__('Midline assessment period starts on')); ?> <?php echo e($school->midline_start_date->format('d/m/Y')); ?>.
                                            <?php else: ?>
                                                <?php echo e(__('Endline assessment period starts on')); ?> <?php echo e($school->endline_start_date->format('d/m/Y')); ?>.
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php elseif($periodStatus === 'expired'): ?>
                            <div class="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
                                <div class="flex">
                                    <div class="flex-shrink-0">
                                        <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm text-red-700">
                                            <?php if($cycle === 'baseline'): ?>
                                                <?php echo e(__('Baseline assessment period ended on')); ?> <?php echo e($school->baseline_end_date->format('d/m/Y')); ?>.
                                            <?php elseif($cycle === 'midline'): ?>
                                                <?php echo e(__('Midline assessment period ended on')); ?> <?php echo e($school->midline_end_date->format('d/m/Y')); ?>.
                                            <?php else: ?>
                                                <?php echo e(__('Endline assessment period ended on')); ?> <?php echo e($school->endline_end_date->format('d/m/Y')); ?>.
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php elseif($periodStatus === 'active'): ?>
                            <div class="mb-4 bg-green-50 border-l-4 border-green-400 p-4">
                                <div class="flex">
                                    <div class="flex-shrink-0">
                                        <svg class="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm text-green-700">
                                            <?php if($cycle === 'baseline'): ?>
                                                <?php echo e(__('Baseline assessment period is active until')); ?> <?php echo e($school->baseline_end_date->format('d/m/Y')); ?>.
                                            <?php elseif($cycle === 'midline'): ?>
                                                <?php echo e(__('Midline assessment period is active until')); ?> <?php echo e($school->midline_end_date->format('d/m/Y')); ?>.
                                            <?php else: ?>
                                                <?php echo e(__('Endline assessment period is active until')); ?> <?php echo e($school->endline_end_date->format('d/m/Y')); ?>.
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <!-- Locked Assessments Notice -->
                    <?php
                        $lockedCount = $students->filter(function($student) {
                            return $student->is_assessment_locked;
                        })->count();
                    ?>
                    <?php if($lockedCount > 0 && !auth()->user()->isAdmin()): ?>
                        <div class="mb-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm text-yellow-700">
                                        <?php echo e(__(':count assessment(s) are locked by administrators and cannot be edited.', ['count' => $lockedCount])); ?>

                                        <?php echo e(__('You can only view these assessments.')); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Floating Column Headers (Mobile) -->
                    <div class="md:hidden fixed bottom-4 left-4 right-4 bg-white rounded-lg shadow-lg p-3 z-50" style="display: none;" id="floatingHeaders">
                        <div class="text-xs text-gray-600 font-medium">
                            <div class="text-center">
                                <div class="text-gray-500"><?php echo e(__('Levels')); ?></div>
                                <div class="text-xs mt-1">
                                    <?php if($subject === 'khmer'): ?>
                                        <?php echo e(__('Beg → Let → Wrd → Par → Sto → C1 → C2')); ?>

                                    <?php else: ?>
                                        <?php echo e(__('Beg → 1D → 2D → Sub → Div → WP')); ?>

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Assessment Table -->
                    <?php if(count($students) > 0): ?>
                    <div class="relative table-container" style="height: calc(100vh - 250px); overflow: auto;">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider sticky left-0 bg-gray-50 z-20">
                                        <?php echo e(__('Student Name')); ?>

                                    </th>
                                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Latest Level')); ?>

                                    </th>
                                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider" colspan="7">
                                        <?php echo e(__('Student Level')); ?>

                                    </th>
                                </tr>
                                <tr class="sticky top-0 z-10 shadow-sm bg-gray-50">
                                    <th class="px-4 py-2 sticky left-0 bg-gray-50 z-20 border-b-2 border-gray-300"></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"></th>
                                    <?php if($subject === 'khmer'): ?>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Beginner')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Letter')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Word')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Paragraph')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Story')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Comp. 1')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Comp. 2')); ?></th>
                                    <?php else: ?>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Beginner')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('1-Digit')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('2-Digit')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Subtraction')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Division')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500 bg-gray-50 border-b-2 border-gray-300"><?php echo e(__('Word Problem')); ?></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="student-row <?php echo e($student->is_assessment_locked ? 'opacity-60' : ''); ?>" data-student-id="<?php echo e($student->id); ?>" data-saved="false" <?php echo e($student->is_assessment_locked ? 'data-locked="true"' : ''); ?>>
                                    <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900 sticky left-0 bg-white z-10" data-student-gender="<?php echo e($student->gender); ?>">
                                        <div class="flex items-center">
                                            <?php echo e($student->name); ?>

                                            <?php if($student->has_assessment): ?>
                                                <?php if($student->is_assessment_locked): ?>
                                                    <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800">
                                                        <svg class="-ml-0.5 mr-1 h-2 w-2" fill="currentColor" viewBox="0 0 8 8">
                                                            <circle cx="4" cy="4" r="3" />
                                                        </svg>
                                                        <?php echo e(__('Locked')); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                                                        <?php echo e(__('Assessed')); ?>

                                                    </span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <!-- Previous Assessment -->
                                    <td class="px-2 py-4 text-center">
                                        <div class="text-sm">
                                            <?php if($student->previous_assessment): ?>
                                                <span class="font-medium text-gray-700"><?php echo e($student->previous_assessment->level); ?></span>
                                                <br>
                                                <span class="text-xs text-gray-500"><?php echo e(ucfirst($student->previous_assessment->cycle)); ?></span>
                                            <?php else: ?>
                                                <span class="text-gray-400">-</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <!-- Levels -->
                                    <?php if($subject === 'khmer'): ?>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Beginner" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Beginner' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Letter" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Letter' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Word" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Word' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Paragraph" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Paragraph' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Story" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Story' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Comp. 1" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Comp. 1' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Comp. 2" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Comp. 2' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <?php else: ?>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Beginner" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Beginner' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="1-Digit" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == '1-Digit' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="2-Digit" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == '2-Digit' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Subtraction" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Subtraction' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Division" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Division' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Word Problem" <?php echo e($student->is_assessment_locked ? 'disabled' : ''); ?> <?php echo e($student->has_assessment && $student->assessment_level == 'Word Problem' ? 'checked' : ''); ?> class="level-radio">
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Submit All Button -->
                    <?php
                        $showSubmitButton = true;
                        if(auth()->user()->school && !auth()->user()->isAdmin()) {
                            $periodStatus = auth()->user()->school->getAssessmentPeriodStatus($cycle);
                            $showSubmitButton = in_array($periodStatus, ['active']);
                        }
                    ?>
                    
                    <?php if($showSubmitButton): ?>
                        <div class="mt-6 flex justify-center">
                            <button type="button" 
                                    id="submitAllBtn"
                                    class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                    onclick="submitAll()">
                                <?php echo e(__('Submit')); ?>

                            </button>
                        </div>
                    <?php else: ?>
                        <div class="mt-6 text-center">
                            <p class="text-sm text-gray-500">
                                <?php if($periodStatus === 'not_set'): ?>
                                    <?php echo e(__('Submit button is disabled. Assessment dates have not been set for your school.')); ?>

                                <?php elseif($periodStatus === 'upcoming'): ?>
                                    <?php echo e(__('Submit button will be enabled when the assessment period begins.')); ?>

                                <?php elseif($periodStatus === 'expired'): ?>
                                    <?php echo e(__('Submit button is disabled. The assessment period has ended.')); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>
                    <?php else: ?>
                    <div class="text-center py-8">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900"><?php echo e(__('No eligible students')); ?></h3>
                        <p class="mt-1 text-sm text-gray-500">
                            <?php if($subject === 'khmer' && in_array($cycle, ['midline', 'endline'])): ?>
                                <?php echo e(__('No students from baseline assessment (Beginner to Story level) found for this cycle.')); ?>

                            <?php elseif($subject === 'math' && in_array($cycle, ['midline', 'endline'])): ?>
                                <?php echo e(__('No students from baseline assessment (Beginner to Subtraction level) found for this cycle.')); ?>

                            <?php else: ?>
                                <?php echo e(__('No students found.')); ?>

                            <?php endif; ?>
                        </p>
                        <?php if($cycle !== 'baseline'): ?>
                        <div class="mt-6">
                            <a href="<?php echo e(route('assessments.create', ['subject' => $subject, 'cycle' => 'baseline'])); ?>" 
                               class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <?php echo e(__('Go to Baseline Assessment')); ?>

                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        let savedCount = 0;
        const totalCount = <?php echo e(count($students)); ?>;
        
        $(document).ready(function() {
            // Load existing assessments
            loadExistingAssessments();
            
            // Check if table is scrollable
            const tableContainer = $('.table-container')[0];
            if (tableContainer) {
                const checkScrollable = () => {
                    if (tableContainer.scrollHeight > tableContainer.clientHeight) {
                        $(tableContainer).addClass('scrollable');
                    } else {
                        $(tableContainer).removeClass('scrollable');
                    }
                };
                
                checkScrollable();
                $(window).on('resize', checkScrollable);
                
                // Show floating headers on scroll (mobile)
                let scrollTimer = null;
                $(tableContainer).on('scroll', function() {
                    if (window.innerWidth < 768) {
                        $('#floatingHeaders').fadeIn(200);
                        
                        clearTimeout(scrollTimer);
                        scrollTimer = setTimeout(() => {
                            $('#floatingHeaders').fadeOut(200);
                        }, 3000);
                    }
                });
            }
            
            // Track changes when level is selected
            $('.level-radio').change(function() {
                const row = $(this).closest('tr');
                const studentId = row.data('student-id');
                
                // Skip if locked
                if (row.attr('data-locked') === 'true') {
                    return;
                }
                
                const hasLevel = $(`input[name="level_${studentId}"]:checked`).length > 0;
                const selectedLevel = $(`input[name="level_${studentId}"]:checked`).val();
                const currentLevel = row.attr('data-current-level');
                
                if (hasLevel) {
                    // Mark row as having unsaved changes
                    row.addClass('bg-yellow-50');
                    
                    // If this is an update and level changed, add visual indicator
                    if (currentLevel && selectedLevel !== currentLevel) {
                        row.addClass('border-l-4 border-orange-500');
                    } else if (currentLevel) {
                        row.removeClass('border-l-4 border-orange-500');
                    }
                }
            });
            
            // Subject or cycle change
            $('#subject, #cycle').change(function() {
                // Reload page with new parameters to get the correct student list
                const subject = $('#subject').val();
                const cycle = $('#cycle').val();
                window.location.href = '<?php echo e(route("assessments.create")); ?>?subject=' + subject + '&cycle=' + cycle;
            });
        });
        
        function loadExistingAssessments() {
            const subject = $('#subject').val();
            const cycle = $('#cycle').val();
            
            // Reset all
            savedCount = 0;
            $('.student-row').each(function() {
                $(this).attr('data-saved', 'false');
                $(this).removeClass('bg-green-50');
                $(this).find('.submit-btn').text('<?php echo e(__("Submit")); ?>').removeClass('bg-green-600').addClass('bg-blue-600');
            });
            
            // Load existing assessments via AJAX
            showLoading('<?php echo e(__("Loading existing assessments...")); ?>');
            $.ajax({
                url: '<?php echo e(route("assessments.index")); ?>',
                data: {
                    subject: subject,
                    cycle: cycle,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    // Process existing assessments
                    if (data.assessments) {
                        data.assessments.forEach(function(assessment) {
                            const row = $(`.student-row[data-student-id="${assessment.student_id}"]`);
                            if (row.length) {
                                // Mark the level
                                row.find(`input[name="level_${assessment.student_id}"][value="${assessment.level}"]`).prop('checked', true);
                                
                                // Mark as saved
                                row.attr('data-saved', 'true');
                                row.attr('data-current-level', assessment.level);
                                row.addClass('bg-green-50');
                                row.removeClass('bg-yellow-50 border-l-4 border-orange-500');
                            }
                        });
                    }
                    updateSavedCount();
                },
                complete: function() {
                    hideLoading();
                }
            });
        }
        
        function updateSavedCount() {
            savedCount = $('.student-row[data-saved="true"]').length;
            $('#savedCount').text(savedCount);
        }
        
        function submitAll() {
            // Collect all assessments with selected levels
            const assessments = [];
            let hasUnsavedChanges = false;
            
            $('.student-row').each(function() {
                const row = $(this);
                const studentId = row.data('student-id');
                
                // Skip if locked
                if (row.attr('data-locked') === 'true') {
                    return;
                }
                
                const level = $(`input[name="level_${studentId}"]:checked`).val();
                const gender = row.find('td:first').data('student-gender') || 'unknown';
                
                if (level) {
                    assessments.push({
                        student_id: studentId,
                        gender: gender,
                        level: level
                    });
                    
                    // Check if this is unsaved
                    if (row.attr('data-saved') !== 'true' || row.attr('data-current-level') !== level) {
                        hasUnsavedChanges = true;
                    }
                }
            });
            
            if (assessments.length === 0) {
                Swal.fire({
                    icon: 'warning',
                    title: '<?php echo e(__("Warning")); ?>',
                    text: '<?php echo e(__("No assessments selected")); ?>'
                });
                return;
            }
            
            const confirmText = hasUnsavedChanges 
                ? `<?php echo e(__("You have assessed")); ?> ${assessments.length} <?php echo e(__("out of")); ?> ${totalCount} <?php echo e(__("students")); ?>. <?php echo e(__("Do you want to save and submit?")); ?>`
                : `<?php echo e(__("All assessments are already saved. Do you want to submit?")); ?>`;
            
            Swal.fire({
                title: '<?php echo e(__("Submit All Assessments?")); ?>',
                text: confirmText,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '<?php echo e(__("Yes, submit all")); ?>',
                cancelButtonText: '<?php echo e(__("Cancel")); ?>'
            }).then((result) => {
                if (result.isConfirmed) {
                    showLoading('<?php echo e(__("Submitting assessments...")); ?>');
                    
                    // Save all assessments
                    const savePromises = assessments.map(assessment => {
                        return $.ajax({
                            url: '<?php echo e(route("api.assessments.save-student")); ?>',
                            method: 'POST',
                            data: {
                                student_id: assessment.student_id,
                                gender: assessment.gender,
                                level: assessment.level,
                                subject: $('#subject').val(),
                                cycle: $('#cycle').val(),
                                _token: '<?php echo e(csrf_token()); ?>'
                            }
                        });
                    });
                    
                    // Wait for all saves to complete
                    Promise.all(savePromises)
                        .then(() => {
                            // Now submit all
                            return $.ajax({
                                url: '<?php echo e(route("api.assessments.submit-all")); ?>',
                                method: 'POST',
                                data: {
                                    subject: $('#subject').val(),
                                    cycle: $('#cycle').val(),
                                    submitted_count: assessments.length,
                                    _token: '<?php echo e(csrf_token()); ?>'
                                }
                            });
                        })
                        .then(response => {
                            if (response.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: '<?php echo e(__("Success")); ?>',
                                    text: response.message,
                                    confirmButtonText: '<?php echo e(__("OK")); ?>'
                                }).then(() => {
                                    window.location.href = response.redirect;
                                });
                            }
                        })
                        .catch(error => {
                            Swal.fire({
                                icon: 'error',
                                title: '<?php echo e(__("Error")); ?>',
                                text: error.responseJSON?.message || '<?php echo e(__("Failed to submit assessments")); ?>'
                            });
                        })
                        .finally(() => {
                            hideLoading();
                        });
                }
            });
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/assessments/create.blade.php ENDPATH**/ ?>