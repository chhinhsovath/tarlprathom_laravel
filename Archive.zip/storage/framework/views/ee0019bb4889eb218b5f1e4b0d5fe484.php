<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    
                    <!-- Subject and Cycle Selection -->
                    <div class="mb-6 flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Subject')); ?>:</label>
                                <select id="subject" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                    <option value="khmer" <?php echo e($subject === 'khmer' ? 'selected' : ''); ?>><?php echo e(__('Khmer')); ?></option>
                                    <option value="math" <?php echo e($subject === 'math' ? 'selected' : ''); ?>><?php echo e(__('Math')); ?></option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Test Cycle')); ?>:</label>
                                <select id="cycle" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                    <option value="baseline" <?php echo e($cycle === 'baseline' ? 'selected' : ''); ?>><?php echo e(__('Baseline')); ?></option>
                                    <option value="midline" <?php echo e($cycle === 'midline' ? 'selected' : ''); ?>><?php echo e(__('Midline')); ?></option>
                                    <option value="endline" <?php echo e($cycle === 'endline' ? 'selected' : ''); ?>><?php echo e(__('Endline')); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="text-sm text-gray-600">
                            <span id="savedCount">0</span> / <span id="totalCount"><?php echo e(count($students)); ?></span> <?php echo e(__('students assessed')); ?>

                        </div>
                    </div>

                    <!-- Assessment Table -->
                    <?php if(count($students) > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Student Name')); ?>

                                    </th>
                                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider" colspan="2">
                                        <?php echo e(__('Student Gender')); ?>

                                    </th>
                                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider" colspan="7">
                                        <?php echo e(__('Student Level')); ?>

                                    </th>
                                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        
                                    </th>
                                </tr>
                                <tr>
                                    <th class="px-4 py-2"></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Male')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Female')); ?></th>
                                    <?php if($subject === 'khmer'): ?>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Beginner')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Letter')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Word')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Paragraph')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Story')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Comp. 1')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Comp. 2')); ?></th>
                                    <?php else: ?>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Beginner')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('1-Digit')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('2-Digit')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Subtraction')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Division')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"><?php echo e(__('Word Problem')); ?></th>
                                    <th class="px-2 py-2 text-center text-xs font-medium text-gray-500"></th>
                                    <?php endif; ?>
                                    <th class="px-4 py-2"></th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="student-row" data-student-id="<?php echo e($student->id); ?>" data-saved="false">
                                    <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo e($student->name); ?>

                                    </td>
                                    <!-- Gender -->
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="gender_<?php echo e($student->id); ?>" value="male" 
                                               <?php echo e($student->gender === 'male' ? 'checked' : ''); ?>

                                               class="gender-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="gender_<?php echo e($student->id); ?>" value="female" 
                                               <?php echo e($student->gender === 'female' ? 'checked' : ''); ?>

                                               class="gender-radio">
                                    </td>
                                    <!-- Levels -->
                                    <?php if($subject === 'khmer'): ?>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Beginner" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Letter Reader" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Word Level" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Paragraph Reader" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Story Reader" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Comp. 1" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Comp. 2" class="level-radio">
                                    </td>
                                    <?php else: ?>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Beginner" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="1-Digit" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="2-Digit" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Subtraction" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Division" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <input type="radio" name="level_<?php echo e($student->id); ?>" value="Word Problem" class="level-radio">
                                    </td>
                                    <td class="px-2 py-4 text-center">
                                        <!-- Empty cell for Math to align with submit button -->
                                    </td>
                                    <?php endif; ?>
                                    <td class="px-4 py-4 text-center">
                                        <button type="button" 
                                                class="submit-btn inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                                                onclick="submitStudent(<?php echo e($student->id); ?>)"
                                                disabled>
                                            <?php echo e(__('Submit')); ?>

                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Submit All Button -->
                    <div class="mt-6 flex justify-center">
                        <button type="button" 
                                id="submitAllBtn"
                                class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                onclick="submitAll()">
                            <?php echo e(__('Submit')); ?>

                        </button>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-8">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900"><?php echo e(__('No eligible students')); ?></h3>
                        <p class="mt-1 text-sm text-gray-500">
                            <?php if($subject === 'khmer' && in_array($cycle, ['midline', 'endline'])): ?>
                                <?php echo e(__('No students from baseline assessment (Beginner to Story level) found for this cycle.')); ?>

                            <?php elseif($subject === 'math' && in_array($cycle, ['midline', 'endline'])): ?>
                                <?php echo e(__('No students from baseline assessment (Beginner to Subtraction level) found for this cycle.')); ?>

                            <?php else: ?>
                                <?php echo e(__('No students found.')); ?>

                            <?php endif; ?>
                        </p>
                        <?php if($cycle !== 'baseline'): ?>
                        <div class="mt-6">
                            <a href="<?php echo e(route('assessments.create', ['subject' => $subject, 'cycle' => 'baseline'])); ?>" 
                               class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <?php echo e(__('Go to Baseline Assessment')); ?>

                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        let savedCount = 0;
        const totalCount = <?php echo e(count($students)); ?>;
        
        $(document).ready(function() {
            // Load existing assessments
            loadExistingAssessments();
            
            // Enable submit button when both gender and level are selected
            $('.gender-radio, .level-radio').change(function() {
                const row = $(this).closest('tr');
                const studentId = row.data('student-id');
                const hasGender = $(`input[name="gender_${studentId}"]:checked`).length > 0;
                const hasLevel = $(`input[name="level_${studentId}"]:checked`).length > 0;
                
                if (hasGender && hasLevel) {
                    row.find('.submit-btn').prop('disabled', false);
                } else {
                    row.find('.submit-btn').prop('disabled', true);
                }
            });
            
            // Subject or cycle change
            $('#subject, #cycle').change(function() {
                // Reload page with new parameters to get the correct student list
                const subject = $('#subject').val();
                const cycle = $('#cycle').val();
                window.location.href = '<?php echo e(route("assessments.create")); ?>?subject=' + subject + '&cycle=' + cycle;
            });
        });
        
        function loadExistingAssessments() {
            const subject = $('#subject').val();
            const cycle = $('#cycle').val();
            
            // Reset all
            savedCount = 0;
            $('.student-row').each(function() {
                $(this).attr('data-saved', 'false');
                $(this).removeClass('bg-green-50');
                $(this).find('.submit-btn').text('<?php echo e(__("Submit")); ?>').removeClass('bg-green-600').addClass('bg-blue-600');
            });
            
            // Load existing assessments via AJAX
            showLoading('<?php echo e(__("Loading existing assessments...")); ?>');
            $.ajax({
                url: '<?php echo e(route("assessments.index")); ?>',
                data: {
                    subject: subject,
                    cycle: cycle,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    // Process existing assessments
                    if (data.assessments) {
                        data.assessments.forEach(function(assessment) {
                            const row = $(`.student-row[data-student-id="${assessment.student_id}"]`);
                            if (row.length) {
                                // Mark the level
                                row.find(`input[name="level_${assessment.student_id}"][value="${assessment.level}"]`).prop('checked', true);
                                
                                // Mark as saved
                                row.attr('data-saved', 'true');
                                row.addClass('bg-green-50');
                                row.find('.submit-btn').text('<?php echo e(__("Saved")); ?>').removeClass('bg-blue-600').addClass('bg-green-600');
                                
                                // Enable the button since it's already saved
                                row.find('.submit-btn').prop('disabled', false);
                            }
                        });
                    }
                    updateSavedCount();
                },
                complete: function() {
                    hideLoading();
                }
            });
        }
        
        function submitStudent(studentId) {
            const row = $(`.student-row[data-student-id="${studentId}"]`);
            const gender = $(`input[name="gender_${studentId}"]:checked`).val();
            const level = $(`input[name="level_${studentId}"]:checked`).val();
            const subject = $('#subject').val();
            const cycle = $('#cycle').val();
            
            if (!gender || !level) {
                Swal.fire({
                    icon: 'error',
                    title: '<?php echo e(__("Error")); ?>',
                    text: '<?php echo e(__("Please select both gender and level")); ?>'
                });
                return;
            }
            
            // Show loading on button
            const btn = row.find('.submit-btn');
            setButtonLoading(btn, true);
            
            $.ajax({
                url: '<?php echo e(route("api.assessments.save-student")); ?>',
                method: 'POST',
                data: {
                    student_id: studentId,
                    gender: gender,
                    level: level,
                    subject: subject,
                    cycle: cycle,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        row.attr('data-saved', 'true');
                        row.addClass('bg-green-50');
                        btn.text('<?php echo e(__("Saved")); ?>').removeClass('bg-blue-600').addClass('bg-green-600');
                        updateSavedCount();
                        
                        // Show toast
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 2000,
                            timerProgressBar: true
                        });
                        
                        Toast.fire({
                            icon: 'success',
                            title: '<?php echo e(__("Assessment saved")); ?>'
                        });
                    }
                },
                error: function(xhr) {
                    Swal.fire({
                        icon: 'error',
                        title: '<?php echo e(__("Error")); ?>',
                        text: xhr.responseJSON?.message || '<?php echo e(__("Failed to save assessment")); ?>'
                    });
                },
                complete: function() {
                    setButtonLoading(btn, false);
                }
            });
        }
        
        function updateSavedCount() {
            savedCount = $('.student-row[data-saved="true"]').length;
            $('#savedCount').text(savedCount);
        }
        
        function submitAll() {
            if (savedCount === 0) {
                Swal.fire({
                    icon: 'warning',
                    title: '<?php echo e(__("Warning")); ?>',
                    text: '<?php echo e(__("No assessments have been saved yet")); ?>'
                });
                return;
            }
            
            Swal.fire({
                title: '<?php echo e(__("Submit All Assessments?")); ?>',
                text: `<?php echo e(__("You have assessed")); ?> ${savedCount} <?php echo e(__("out of")); ?> ${totalCount} <?php echo e(__("students")); ?>. <?php echo e(__("Do you want to submit?")); ?>`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '<?php echo e(__("Yes, submit all")); ?>',
                cancelButtonText: '<?php echo e(__("Cancel")); ?>'
            }).then((result) => {
                if (result.isConfirmed) {
                    showLoading('<?php echo e(__("Submitting assessments...")); ?>');
                    $.ajax({
                        url: '<?php echo e(route("api.assessments.submit-all")); ?>',
                        method: 'POST',
                        data: {
                            subject: $('#subject').val(),
                            cycle: $('#cycle').val(),
                            submitted_count: savedCount,
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: '<?php echo e(__("Success")); ?>',
                                    text: response.message,
                                    confirmButtonText: '<?php echo e(__("OK")); ?>'
                                }).then(() => {
                                    window.location.href = response.redirect;
                                });
                            }
                        },
                        error: function(xhr) {
                            Swal.fire({
                                icon: 'error',
                                title: '<?php echo e(__("Error")); ?>',
                                text: xhr.responseJSON?.message || '<?php echo e(__("Failed to submit assessments")); ?>'
                            });
                        },
                        complete: function() {
                            hideLoading();
                        }
                    });
                }
            });
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/user/Desktop/apps/tarlprathom_laravel/resources/views/assessments/create.blade.php ENDPATH**/ ?>