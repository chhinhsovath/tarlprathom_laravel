<?php return array (
  'app' => 
  array (
    'name' => 'TaRL Project',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://127.0.0.1:8002',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'km',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'available_locales' => 
    array (
      0 => 'en',
      1 => 'km',
    ),
    'key' => 'base64:Kj2g4Xcw9Y3GOsfT9Lt5ShsE9udOEVNz/cnvZZSQiKI=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'App\\Providers\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'cache',
        'lock_connection' => NULL,
        'lock_table' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/home/dashfiyn/tarl.dashboardkh.com/storage/framework/cache/data',
        'lock_path' => '/home/dashfiyn/tarl.dashboardkh.com/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => '',
  ),
  'charts' => 
  array (
    'colors' => 
    array (
      'progress' => 
      array (
        'improved' => '#22c55e',
        'maintained' => '#fbbf24',
        'declined' => '#ef4444',
      ),
      'cycles' => 
      array (
        'baseline' => '#fb923c',
        'midline' => '#c2410c',
        'endline' => '#2563eb',
      ),
      'tarl_levels' => 
      array (
        0 => '#ef4444',
        1 => '#f59e0b',
        2 => '#eab308',
        3 => '#84cc16',
        4 => '#22c55e',
        5 => '#10b981',
        6 => '#14b8a6',
      ),
      'general' => 
      array (
        0 => '#3b82f6',
        1 => '#ef4444',
        2 => '#10b981',
        3 => '#f59e0b',
        4 => '#8b5cf6',
        5 => '#06b6d4',
        6 => '#84cc16',
        7 => '#f97316',
      ),
    ),
    'defaults' => 
    array (
      'responsive' => true,
      'maintainAspectRatio' => false,
      'borderWidth' => 2,
      'borderColor' => '#ffffff',
      'font' => 
      array (
        'family' => 'Inter, system-ui, sans-serif',
        'size' => 12,
      ),
    ),
    'css_classes' => 
    array (
      'progress' => 
      array (
        'improved' => 
        array (
          'bg' => 'bg-green-50',
          'border' => 'border-green-200',
          'text' => 'text-green-800',
          'text_light' => 'text-green-600',
          'text_lighter' => 'text-green-500',
          'text_lightest' => 'text-green-400',
        ),
        'maintained' => 
        array (
          'bg' => 'bg-yellow-50',
          'border' => 'border-yellow-200',
          'text' => 'text-yellow-800',
          'text_light' => 'text-yellow-600',
          'text_lighter' => 'text-yellow-500',
          'text_lightest' => 'text-yellow-400',
        ),
        'declined' => 
        array (
          'bg' => 'bg-red-50',
          'border' => 'border-red-200',
          'text' => 'text-red-800',
          'text_light' => 'text-red-600',
          'text_lighter' => 'text-red-500',
          'text_lightest' => 'text-red-400',
        ),
      ),
    ),
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
      2 => '*',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => 'https://plp.moeys.gov.kh',
      1 => 'https://tarl.dashbboardkh.com',
      2 => 'http://localhost:8001',
      3 => 'http://127.0.0.1:8001',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => true,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'dashfiyn_tarlprathom',
        'prefix' => '',
        'foreign_key_constraints' => true,
        'busy_timeout' => NULL,
        'journal_mode' => NULL,
        'synchronous' => NULL,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'dashfiyn_tarlprathom',
        'username' => 'dashfiyn_tarlprathom',
        'password' => 'dashfiyn_tarlprathom',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => false,
        'engine' => NULL,
        'modes' => 
        array (
        ),
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'dashfiyn_tarlprathom',
        'username' => 'dashfiyn_tarlprathom',
        'password' => 'dashfiyn_tarlprathom',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'dashfiyn_tarlprathom',
        'username' => 'dashfiyn_tarlprathom',
        'password' => 'dashfiyn_tarlprathom',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'dashfiyn_tarlprathom',
        'username' => 'dashfiyn_tarlprathom',
        'password' => 'dashfiyn_tarlprathom',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'tarl_project_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'database-optimization' => 
  array (
    'remote_optimizations' => 
    array (
      'enable_query_cache' => true,
      'query_cache_duration' => 300,
      'persistent_connections' => true,
      'pool_min' => 2,
      'pool_max' => 10,
      'connection_timeout' => 10,
      'command_timeout' => 60,
      'retry_times' => 3,
      'retry_delay' => 100,
    ),
    'query_optimizations' => 
    array (
      'auto_index' => false,
      'slow_query_threshold' => 1000,
      'cacheable_tables' => 
      array (
        0 => 'users',
        1 => 'schools',
        2 => 'provinces',
        3 => 'districts',
        4 => 'communes',
        5 => 'villages',
        6 => 'translations',
        7 => 'settings',
      ),
      'table_cache_duration' => 
      array (
        'translations' => 3600,
        'settings' => 1800,
        'provinces' => 86400,
        'districts' => 86400,
        'communes' => 86400,
        'villages' => 86400,
        'default' => 300,
      ),
    ),
    'monitoring' => 
    array (
      'enabled' => true,
      'alert_threshold' => 5000,
      'log_connections' => false,
      'monitor_queries' => true,
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/home/dashfiyn/tarl.dashboardkh.com/storage/app/private',
        'serve' => true,
        'throw' => false,
        'report' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/home/dashfiyn/tarl.dashboardkh.com/storage/app/public',
        'url' => 'http://127.0.0.1:8002/storage',
        'visibility' => 'public',
        'throw' => false,
        'report' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'report' => false,
      ),
    ),
    'links' => 
    array (
      '/home/dashfiyn/tarl.dashboardkh.com/public/storage' => '/home/dashfiyn/tarl.dashboardkh.com/storage/app/public',
    ),
  ),
  'livewire' => 
  array (
    'class_namespace' => 'App\\Livewire',
    'view_path' => '/home/dashfiyn/tarl.dashboardkh.com/resources/views/livewire',
    'layout' => 'components.layouts.app',
    'lazy_placeholder' => NULL,
    'temporary_file_upload' => 
    array (
      'disk' => NULL,
      'rules' => NULL,
      'directory' => NULL,
      'middleware' => NULL,
      'preview_mimes' => 
      array (
        0 => 'png',
        1 => 'gif',
        2 => 'bmp',
        3 => 'svg',
        4 => 'wav',
        5 => 'mp4',
        6 => 'mov',
        7 => 'avi',
        8 => 'wmv',
        9 => 'mp3',
        10 => 'm4a',
        11 => 'jpg',
        12 => 'jpeg',
        13 => 'mpga',
        14 => 'webp',
        15 => 'wma',
      ),
      'max_upload_time' => 5,
      'cleanup' => true,
    ),
    'render_on_redirect' => false,
    'legacy_model_binding' => false,
    'inject_assets' => true,
    'navigate' => 
    array (
      'show_progress_bar' => true,
      'progress_bar_color' => '#2299dd',
    ),
    'inject_morph_markers' => true,
    'pagination_theme' => 'tailwind',
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/home/dashfiyn/tarl.dashboardkh.com/storage/logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/home/dashfiyn/tarl.dashboardkh.com/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/home/dashfiyn/tarl.dashboardkh.com/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'log',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'scheme' => NULL,
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '2525',
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => '127.0.0.1',
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'TaRL Project',
    ),
  ),
  'mentoring' => 
  array (
    'questionnaire' => 
    array (
      'visit_details' => 
      array (
        'date_of_visit' => 
        array (
          'type' => 'date',
          'required' => true,
        ),
        'region' => 
        array (
          'type' => 'text',
          'required' => true,
        ),
        'province' => 
        array (
          'type' => 'text',
          'required' => true,
        ),
        'mentor_name' => 
        array (
          'type' => 'select',
          'required' => true,
          'source' => 'mentors',
        ),
        'school_name' => 
        array (
          'type' => 'select',
          'required' => true,
          'source' => 'schools',
        ),
        'program_type' => 
        array (
          'type' => 'text',
          'required' => true,
          'default' => 'TaRL',
        ),
      ),
      'program_type_questions' => 
      array (
        'class_taking_place' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Is the TaRL class taking place on the day of the visit?',
        ),
        'class_not_taking_place_reason' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Teacher is Absent',
            1 => 'Most students are absent',
            2 => 'The students have exams',
            3 => 'The school has declared a holiday',
            4 => 'Others',
          ),
          'condition' => 'class_taking_place:No',
          'question' => 'Why is the TaRL class not taking place?',
        ),
      ),
      'teacher_observation' => 
      array (
        'teacher_name' => 
        array (
          'type' => 'select',
          'required' => true,
          'source' => 'teachers',
          'question' => 'Name of Teacher',
        ),
        'full_session_observed' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Did you observe the full session?',
        ),
        'grade_group' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Std. 1-2',
            1 => 'Std. 3-6',
          ),
          'required' => true,
          'question' => 'Grade Group',
        ),
        'grades_observed' => 
        array (
          'type' => 'checkbox',
          'options' => 
          array (
            0 => '1',
            1 => '2',
            2 => '3',
            3 => '4',
            4 => '5',
            5 => '6',
          ),
          'required' => true,
          'question' => 'Grade(s) Observed',
        ),
        'subject_observed' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Language',
            1 => 'Numeracy',
          ),
          'required' => true,
          'question' => 'Subject Observed',
        ),
        'language_levels' => 
        array (
          'type' => 'checkbox',
          'options' => 
          array (
            0 => 'Beginner',
            1 => 'Letter Level',
            2 => 'Word',
            3 => 'Paragraph',
            4 => 'Story',
          ),
          'condition' => 'subject_observed:Language',
          'question' => 'TaRL Level(s) observed (Language)',
        ),
        'numeracy_levels' => 
        array (
          'type' => 'checkbox',
          'options' => 
          array (
            0 => 'Beginner',
            1 => '1-Digit',
            2 => '2-Digit',
            3 => 'Subtraction',
            4 => 'Division',
          ),
          'condition' => 'subject_observed:Numeracy',
          'question' => 'TaRL Level(s) observed (Numeracy)',
        ),
      ),
      'delivery_questions' => 
      array (
        'class_started_on_time' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Did the class start on time (i.e. within 5 minutes of the scheduled time)?',
        ),
        'late_start_reason' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Teacher came late',
            1 => 'Pupils came late',
            2 => 'Others',
          ),
          'condition' => 'class_started_on_time:No',
          'question' => 'If no, then why did the class not start on time?',
        ),
      ),
      'classroom_questions' => 
      array (
        'materials_present' => 
        array (
          'type' => 'checkbox',
          'options' => 
          array (
            0 => 'TaRL materials',
            1 => 'Teaching aids',
            2 => 'Student notebooks',
            3 => 'Reading materials',
            4 => 'Math manipulatives',
            5 => 'Flash cards',
            6 => 'Number charts',
            7 => 'Letter charts',
            8 => 'Story books',
            9 => 'Activity sheets',
          ),
          'question' => 'Which materials did you see present in the classroom?',
        ),
        'children_grouped_appropriately' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Were the children grouped appropriately?',
        ),
        'students_fully_involved' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Were the students fully involved in the activities?',
        ),
      ),
      'teacher_questions' => 
      array (
        'has_session_plan' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Did the teacher have a session plan?',
        ),
        'no_session_plan_reason' => 
        array (
          'type' => 'text',
          'condition' => 'has_session_plan:No',
          'question' => 'Why did the teacher not have a session plan?',
        ),
        'followed_session_plan' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Did the teacher follow the session plan?',
          'condition' => 'has_session_plan:Yes',
        ),
        'no_follow_plan_reason' => 
        array (
          'type' => 'text',
          'condition' => 'followed_session_plan:No',
          'question' => 'Why did the teacher not follow the session plan?',
        ),
        'session_plan_appropriate' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Was the session plan appropriate for the children\'s learning level?',
          'condition' => 'has_session_plan:Yes',
        ),
      ),
      'activity_overview' => 
      array (
        'number_of_activities' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => '1',
            1 => '2',
            2 => '3',
          ),
          'required' => true,
          'question' => 'How many activities were conducted?',
        ),
      ),
      'activity_1' => 
      array (
        'activity1_name_language' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Letter recognition',
            1 => 'Letter writing',
            2 => 'Word building',
            3 => 'Word reading',
            4 => 'Sentence reading',
            5 => 'Story reading',
            6 => 'Comprehension activities',
            7 => 'Vocabulary games',
            8 => 'Phonics activities',
            9 => 'Others',
          ),
          'condition' => 'subject_observed:Language',
          'question' => 'Which was the first activity conducted? (Language)',
        ),
        'activity1_name_numeracy' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Number chart reading activity',
            1 => 'Recognition of the numbers with symbol and objects',
            2 => 'Puzzles',
            3 => 'Number Jump',
            4 => 'Basket game',
            5 => 'Clap and Snap',
            6 => 'What next - Count Before / Count After',
            7 => 'Number line - Counting and find the numbers move to left and move to right',
            8 => 'Fine with Nine',
            9 => 'Place value - Bundle and sticks with numbers up to 20',
            10 => 'Making bundles and counting 10, 20, 30, 40, …',
            11 => 'Learning two digit numbers with bundle and sticks',
            12 => 'Addition of single digit numbers with sticks and without any material by using frame and word problems',
            13 => 'Subtraction of single digit numbers with sticks and without any material, by using and word problems',
            14 => 'Word problem of two digit number of addition and subtraction without any material',
            15 => 'Who is my third partner - with numbers 1 to 9',
          ),
          'condition' => 'subject_observed:Numeracy',
          'question' => 'Which was the first activity conducted? (Numeracy)',
        ),
        'activity1_duration' => 
        array (
          'type' => 'number',
          'required' => true,
          'question' => 'What was the duration of the first activity? (Mins)',
        ),
        'activity1_clear_instructions' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Did the teacher give clear instructions for the first activity?',
        ),
        'activity1_no_clear_instructions_reason' => 
        array (
          'type' => 'text',
          'condition' => 'activity1_clear_instructions:No',
          'question' => 'Why did the teacher not give clear instructions for the first activity?',
        ),
        'activity1_demonstrated' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Did the teacher demonstrate the first activity?',
        ),
        'activity1_students_practice' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
            2 => 'Not applicable',
          ),
          'required' => true,
          'question' => 'Did the teacher make a few students practice the first activity in front of the whole class?',
        ),
        'activity1_small_groups' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
            2 => 'Not Applicable',
          ),
          'required' => true,
          'question' => 'Did the students perform the first activity in small groups?',
        ),
        'activity1_individual' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
            2 => 'Not Applicable',
          ),
          'required' => true,
          'question' => 'Did the students individually perform the first activity?',
        ),
      ),
      'activity_2' => 
      array (
        'activity2_name_language' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Letter recognition',
            1 => 'Letter writing',
            2 => 'Word building',
            3 => 'Word reading',
            4 => 'Sentence reading',
            5 => 'Story reading',
            6 => 'Comprehension activities',
            7 => 'Vocabulary games',
            8 => 'Phonics activities',
            9 => 'Others',
          ),
          'condition' => 'subject_observed:Language,number_of_activities:2|3',
          'question' => 'Which was the second activity conducted? (Language)',
        ),
        'activity2_name_numeracy' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Number chart reading activity',
            1 => 'Recognition of the numbers with symbol and objects',
            2 => 'Puzzles',
            3 => 'Number Jump',
            4 => 'Basket game',
            5 => 'Clap and Snap',
            6 => 'What next - Count Before / Count After',
            7 => 'Number line - Counting and find the numbers move to left and move to right',
            8 => 'Fine with Nine',
            9 => 'Place value - Bundle and sticks with numbers up to 20',
            10 => 'Making bundles and counting 10, 20, 30, 40, …',
            11 => 'Learning two digit numbers with bundle and sticks',
            12 => 'Addition of single digit numbers with sticks and without any material by using frame and word problems',
            13 => 'Subtraction of single digit numbers with sticks and without any material, by using and word problems',
            14 => 'Word problem of two digit number of addition and subtraction without any material',
            15 => 'Who is my third partner - with numbers 1 to 9',
          ),
          'condition' => 'subject_observed:Numeracy,number_of_activities:2|3',
          'question' => 'Which was the second activity conducted? (Numeracy)',
        ),
        'activity2_duration' => 
        array (
          'type' => 'number',
          'condition' => 'number_of_activities:2|3',
          'question' => 'What was the duration of the second activity? (Mins)',
        ),
        'activity2_clear_instructions' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'condition' => 'number_of_activities:2|3',
          'question' => 'Did the teacher give clear instructions for the second activity?',
        ),
        'activity2_no_clear_instructions_reason' => 
        array (
          'type' => 'text',
          'condition' => 'activity2_clear_instructions:No',
          'question' => 'Why did the teacher not give clear instructions for the second activity?',
        ),
        'activity2_demonstrated' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'condition' => 'number_of_activities:2|3',
          'question' => 'Did the teacher demonstrate the second activity?',
        ),
        'activity2_students_practice' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'condition' => 'number_of_activities:2|3',
          'question' => 'Did the teacher make a few students practice the second activity in front of the whole class?',
        ),
        'activity2_small_groups' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'condition' => 'number_of_activities:2|3',
          'question' => 'Did the students perform the second activity in small groups?',
        ),
        'activity2_individual' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'condition' => 'number_of_activities:2|3',
          'question' => 'Did the students individually perform the second activity?',
        ),
      ),
      'activity_3' => 
      array (
        'activity3_name_language' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Letter recognition',
            1 => 'Letter writing',
            2 => 'Word building',
            3 => 'Word reading',
            4 => 'Sentence reading',
            5 => 'Story reading',
            6 => 'Comprehension activities',
            7 => 'Vocabulary games',
            8 => 'Phonics activities',
            9 => 'Others',
          ),
          'condition' => 'subject_observed:Language,number_of_activities:3',
          'question' => 'Which was the third activity conducted? (Language)',
        ),
        'activity3_name_numeracy' => 
        array (
          'type' => 'select',
          'options' => 
          array (
            0 => 'Number chart reading activity',
            1 => 'Recognition of the numbers with symbol and objects',
            2 => 'Puzzles',
            3 => 'Number Jump',
            4 => 'Basket game',
            5 => 'Clap and Snap',
            6 => 'What next - Count Before / Count After',
            7 => 'Number line - Counting and find the numbers move to left and move to right',
            8 => 'Fine with Nine',
            9 => 'Place value - Bundle and sticks with numbers up to 20',
            10 => 'Making bundles and counting 10, 20, 30, 40, …',
            11 => 'Learning two digit numbers with bundle and sticks',
            12 => 'Addition of single digit numbers with sticks and without any material by using frame and word problems',
            13 => 'Subtraction of single digit numbers with sticks and without any material, by using and word problems',
            14 => 'Word problem of two digit number of addition and subtraction without any material',
            15 => 'Who is my third partner - with numbers 1 to 9',
          ),
          'condition' => 'subject_observed:Numeracy,number_of_activities:3',
          'question' => 'Which was the third activity conducted? (Numeracy)',
        ),
        'activity3_duration' => 
        array (
          'type' => 'number',
          'condition' => 'number_of_activities:3',
          'question' => 'What was the duration of the third activity? (Mins)',
        ),
        'activity3_clear_instructions' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'condition' => 'number_of_activities:3',
          'question' => 'Did the teacher give clear instructions for the third activity?',
        ),
        'activity3_no_clear_instructions_reason' => 
        array (
          'type' => 'text',
          'condition' => 'activity3_clear_instructions:No',
          'question' => 'Why did the teacher not give clear instructions for the third activity?',
        ),
        'activity3_demonstrated' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'condition' => 'number_of_activities:3',
          'question' => 'Did the teacher demonstrate the activity?',
        ),
        'activity3_students_practice' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
            2 => 'Not Applicable',
          ),
          'condition' => 'number_of_activities:3',
          'question' => 'Did the teacher make a few students practice the third activity in front of the whole class?',
        ),
        'activity3_small_groups' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
            2 => 'Not Applicable',
          ),
          'condition' => 'number_of_activities:3',
          'question' => 'Did the students perform the third activity in small groups?',
        ),
        'activity3_individual' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
            2 => 'Not Applicable',
          ),
          'condition' => 'number_of_activities:3',
          'question' => 'Did the students individually perform the third activity?',
        ),
      ),
      'additional_observations' => 
      array (
        'overall_observation' => 
        array (
          'type' => 'textarea',
          'required' => false,
          'question' => 'General observations about the visit',
        ),
        'action_plan' => 
        array (
          'type' => 'textarea',
          'required' => false,
          'question' => 'Action plan and recommendations',
        ),
        'follow_up_required' => 
        array (
          'type' => 'radio',
          'options' => 
          array (
            0 => 'Yes',
            1 => 'No',
          ),
          'required' => true,
          'question' => 'Is follow-up required?',
        ),
        'photo' => 
        array (
          'type' => 'file',
          'accept' => 'image/*',
          'required' => false,
          'question' => 'Upload photo from visit',
        ),
      ),
    ),
    'scoring' => 
    array (
      'max_score' => 100,
      'sections' => 
      array (
        'class_preparation' => 20,
        'teaching_methodology' => 30,
        'student_engagement' => 25,
        'materials_usage' => 15,
        'overall_effectiveness' => 10,
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/home/dashfiyn/tarl.dashboardkh.com/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'tarl_project_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'none',
    'partitioned' => false,
  ),
  'uploads' => 
  array (
    'max_file_size' => 
    array (
      'profile_photo' => 5120,
      'student_photo' => 5120,
      'mentoring_photo' => 5120,
      'csv_import' => 10240,
    ),
    'allowed_mimes' => 
    array (
      'images' => 
      array (
        0 => 'jpeg',
        1 => 'png',
        2 => 'jpg',
        3 => 'gif',
      ),
      'documents' => 
      array (
        0 => 'pdf',
        1 => 'doc',
        2 => 'docx',
      ),
      'spreadsheets' => 
      array (
        0 => 'csv',
        1 => 'xls',
        2 => 'xlsx',
      ),
    ),
    'storage_paths' => 
    array (
      'profile_photos' => 'users/photos',
      'student_photos' => 'students/photos',
      'mentoring_photos' => 'mentoring/photos',
      'imports' => 'imports',
      'exports' => 'exports',
    ),
    'image_dimensions' => 
    array (
      'profile_photo' => 
      array (
        'width' => 500,
        'height' => 500,
      ),
      'student_photo' => 
      array (
        'width' => 400,
        'height' => 400,
      ),
      'mentoring_photo' => 
      array (
        'width' => 800,
        'height' => 600,
      ),
    ),
    'image_quality' => 85,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/home/dashfiyn/tarl.dashboardkh.com/resources/views',
    ),
    'compiled' => '/home/dashfiyn/tarl.dashboardkh.com/storage/framework/views',
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'strict_null_comparison' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
        'output_encoding' => '',
        'test_auto_detect' => true,
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'ignore_empty' => false,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => NULL,
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'guess',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
      'cells' => 
      array (
        'middleware' => 
        array (
        ),
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'driver' => 'memory',
      'batch' => 
      array (
        'memory_limit' => 60000,
      ),
      'illuminate' => 
      array (
        'store' => NULL,
      ),
      'default_ttl' => 10800,
    ),
    'transactions' => 
    array (
      'handler' => 'db',
      'db' => 
      array (
        'connection' => NULL,
      ),
    ),
    'temporary_files' => 
    array (
      'local_path' => '/home/dashfiyn/tarl.dashboardkh.com/storage/framework/cache/laravel-excel',
      'local_permissions' => 
      array (
      ),
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
