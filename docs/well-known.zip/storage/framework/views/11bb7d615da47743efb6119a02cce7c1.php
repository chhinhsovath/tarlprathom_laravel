<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="w-full px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
            <div class="p-6 bg-white border-b border-gray-200">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-2xl font-bold text-gray-900"><?php echo e(trans_db('Performance Calculation Report')); ?></h2>
                    <a href="<?php echo e(route('reports.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                        ← <?php echo e(trans_db('Back to Reports')); ?>

                    </a>
                </div>
                <p class="text-gray-600 mb-4"><?php echo e(trans_db('Analysis of student performance based on reading levels and mathematical operations capability')); ?></p>
                
                <!-- Filters -->
                <form method="GET" class="bg-gray-50 p-6 rounded-lg mb-6">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div>
                            <label for="school_id" class="block text-sm font-medium text-gray-700 mb-1">
                                <?php echo e(trans_db('School')); ?>

                            </label>
                            <select name="school_id" id="school_id" class="w-full h-11 border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value=""><?php echo e(trans_db('All Schools')); ?></option>
                                <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($school->id); ?>" <?php echo e($schoolId == $school->id ? 'selected' : ''); ?>>
                                        <?php echo e($school->school_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="cycle" class="block text-sm font-medium text-gray-700 mb-1">
                                <?php echo e(trans_db('Assessment Cycle')); ?>

                            </label>
                            <select name="cycle" id="cycle" class="w-full h-11 border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="baseline" <?php echo e($cycle === 'baseline' ? 'selected' : ''); ?>><?php echo e(trans_db('baseline')); ?></option>
                                <option value="midline" <?php echo e($cycle === 'midline' ? 'selected' : ''); ?>><?php echo e(trans_db('midline')); ?></option>
                                <option value="endline" <?php echo e($cycle === 'endline' ? 'selected' : ''); ?>><?php echo e(trans_db('endline')); ?></option>
                            </select>
                        </div>
                        
                        <div></div>
                        
                        <div class="flex items-end">
                            <button type="submit" class="w-full h-11 inline-flex justify-center items-center px-4 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition">
                                <?php echo e(trans_db('Filter Results')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Performance Calculation Explanation -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
            <div class="p-8 bg-white border-b border-gray-200">
                <h3 class="text-xl font-medium text-gray-900 mb-6"><?php echo e(trans_db('Calculation of Performance')); ?></h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Language Performance -->
                    <div class="bg-blue-50 p-6 rounded-lg">
                        <h4 class="font-semibold text-blue-900 mb-3 text-lg"><?php echo e(trans_db('a. Language -')); ?></h4>
                        <div class="text-base text-blue-800 space-y-2">
                            <div class="ml-4">
                                <span class="font-medium">i.</span> <?php echo e(trans_db('Readers = Para + Story + Comp 1 + Comp 2')); ?>

                            </div>
                            <div class="ml-4">
                                <span class="font-medium">ii.</span> <?php echo e(trans_db('Beginners = Beginner + Letter')); ?>

                            </div>
                        </div>
                    </div>
                    
                    <!-- Math Performance -->
                    <div class="bg-green-50 p-6 rounded-lg">
                        <h4 class="font-semibold text-green-900 mb-3 text-lg"><?php echo e(trans_db('b. Math -')); ?></h4>
                        <div class="text-base text-green-800 space-y-2">
                            <div class="ml-4">
                                <span class="font-medium">i.</span> <?php echo e(trans_db('Students who can do operations = Subtraction + Division + Word Problem')); ?>

                            </div>
                            <div class="ml-4">
                                <span class="font-medium">ii.</span> <?php echo e(trans_db('Beginners = Beginner + 1-Digit')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Chart -->
        <?php if(count($schoolPerformanceData) > 0): ?>
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
            <div class="p-8 bg-white border-b border-gray-200">
                <h3 class="text-xl font-medium text-gray-900 mb-6"><?php echo e(trans_db('c. Sample graph')); ?></h3>
                
                <!-- Chart container -->
                <div class="bg-yellow-50 p-8 rounded-lg">
                    <h4 class="font-semibold text-center mb-6 text-lg text-gray-800">
                        <?php echo e(trans_db('Children who can read at least a simple paragraph')); ?>

                    </h4>
                    
                    <!-- Chart -->
                    <div class="relative" style="height: 500px;">
                        <canvas id="performanceChart"></canvas>
                    </div>
                    
                    <!-- Legend -->
                    <div class="flex justify-center mt-4 space-x-6">
                        <div class="flex items-center">
                            <div class="w-4 h-4 bg-orange-400 rounded mr-2"></div>
                            <span class="text-sm"><?php echo e(trans_db('baseline')); ?></span>
                        </div>
                        <div class="flex items-center">
                            <div class="w-4 h-4 bg-orange-600 rounded mr-2"></div>
                            <span class="text-sm"><?php echo e(trans_db('midline')); ?></span>
                        </div>
                        <div class="flex items-center">
                            <div class="w-4 h-4 bg-blue-600 rounded mr-2"></div>
                            <span class="text-sm"><?php echo e(trans_db('endline')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Performance Data Table -->
        <?php if(count($schoolPerformanceData) > 0): ?>
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-8 bg-white">
                <h3 class="text-xl font-medium text-gray-900 mb-6"><?php echo e(trans_db('Performance Data - ') . trans_db(ucfirst($cycle))); ?></h3>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-8 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('School')); ?>

                                </th>
                                <th class="px-8 py-4 text-center text-sm font-medium text-gray-500 uppercase tracking-wider" colspan="3">
                                    <?php echo e(trans_db('Language Performance')); ?>

                                </th>
                                <th class="px-8 py-4 text-center text-sm font-medium text-gray-500 uppercase tracking-wider" colspan="3">
                                    <?php echo e(trans_db('Math Performance')); ?>

                                </th>
                            </tr>
                            <tr class="bg-gray-100">
                                <th class="px-8 py-3 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('Name')); ?>

                                </th>
                                <th class="px-8 py-3 text-center text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('Total Students')); ?>

                                </th>
                                <th class="px-8 py-3 text-center text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('Readers')); ?>

                                </th>
                                <th class="px-8 py-3 text-center text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('Beginners')); ?>

                                </th>
                                <th class="px-8 py-3 text-center text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('Total Students')); ?>

                                </th>
                                <th class="px-8 py-3 text-center text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('Operations')); ?>

                                </th>
                                <th class="px-8 py-3 text-center text-sm font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(trans_db('Beginners')); ?>

                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $schoolPerformanceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-8 py-6 whitespace-nowrap text-base font-medium text-gray-900">
                                    <?php echo e($data['school']->school_name); ?>

                                </td>
                                
                                <!-- Language Performance -->
                                <td class="px-8 py-6 whitespace-nowrap text-base text-center text-gray-500">
                                    <?php echo e($data['language']['total_students']); ?>

                                </td>
                                <td class="px-8 py-6 whitespace-nowrap text-base text-center">
                                    <div class="text-gray-900 font-medium"><?php echo e($data['language']['readers']); ?></div>
                                    <div class="text-sm text-gray-500">(<?php echo e($data['language']['readers_percentage']); ?>%)</div>
                                </td>
                                <td class="px-8 py-6 whitespace-nowrap text-base text-center">
                                    <div class="text-gray-900 font-medium"><?php echo e($data['language']['beginners']); ?></div>
                                    <div class="text-sm text-gray-500">(<?php echo e($data['language']['beginners_percentage']); ?>%)</div>
                                </td>
                                
                                <!-- Math Performance -->
                                <td class="px-8 py-6 whitespace-nowrap text-base text-center text-gray-500">
                                    <?php echo e($data['math']['total_students']); ?>

                                </td>
                                <td class="px-8 py-6 whitespace-nowrap text-base text-center">
                                    <div class="text-gray-900 font-medium"><?php echo e($data['math']['operations']); ?></div>
                                    <div class="text-sm text-gray-500">(<?php echo e($data['math']['operations_percentage']); ?>%)</div>
                                </td>
                                <td class="px-8 py-6 whitespace-nowrap text-base text-center">
                                    <div class="text-gray-900 font-medium"><?php echo e($data['math']['beginners']); ?></div>
                                    <div class="text-sm text-gray-500">(<?php echo e($data['math']['beginners_percentage']); ?>%)</div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-12 bg-white text-center">  
                <div class="text-gray-500">
                    <svg class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                    <h3 class="text-lg font-medium text-gray-900 mb-2"><?php echo e(trans_db('No Performance Data Available')); ?></h3>
                    <p class="text-gray-600"><?php echo e(trans_db('No assessment data found for the selected criteria. Please try different filters or ensure assessments have been completed.')); ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if(count($schoolPerformanceData) > 0): ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// Translation strings for JavaScript charts
const chartTranslations = {
    'cycle': <?php echo json_encode(trans_db(ucfirst($cycle)), 15, 512) ?>
};

document.addEventListener('DOMContentLoaded', function() {
    try {
        const ctx = document.getElementById('performanceChart');
        if (!ctx) {
            console.error('Canvas element not found');
            return;
        }
        
        // Sample data for demonstration - in real implementation this would come from multiple cycles
        const schoolNames = <?php echo json_encode(collect($schoolPerformanceData)->pluck('school')->toArray(), 15, 512) ?>;
        const languageReaderPercentages = <?php echo json_encode(collect($schoolPerformanceData)->pluck('language.readers_percentage')->filter()->values()->toArray(), 15, 512) ?>;
        
        console.log('School Names:', schoolNames);
        console.log('Reader Percentages:', languageReaderPercentages);
        
        // Check if we have data
        if (!languageReaderPercentages || languageReaderPercentages.length === 0) {
            console.warn('No data to display in chart');
            return;
        }
        
        // For now, using current cycle data, but in real implementation you'd need data from all three cycles
        const chart = new Chart(ctx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: schoolNames.map(school => school.school_name),
            datasets: [{
                label: chartTranslations['cycle'],
                data: languageReaderPercentages,
                backgroundColor: <?php echo json_encode(config('charts.colors.cycles.' . $cycle), 15, 512) ?> + '80', // Add transparency
                borderColor: <?php echo json_encode(config('charts.colors.cycles.' . $cycle), 15, 512) ?>,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '%';
                        }
                    }
                }
            }
        }
    });
    } catch (error) {
        console.error('Error creating chart:', error);
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/reports/performance-calculation-localized.blade.php ENDPATH**/ ?>