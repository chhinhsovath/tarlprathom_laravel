<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Help & Support')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <!-- Welcome Section -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('Welcome to TaRL Assessment System Help')); ?></h3>
                    <p class="text-gray-600 mb-2"><?php echo e(__('This system is designed specifically for Grade 4 and Grade 5 students only.')); ?></p>
                    <p class="text-gray-600"><?php echo e(__('Find step-by-step instructions and learn how to use the system effectively.')); ?></p>
                </div>
            </div>

            <!-- Quick Navigation -->
            <div class="bg-indigo-50 border border-indigo-200 rounded-lg p-4 mb-6">
                <h4 class="font-medium text-indigo-900 mb-2"><?php echo e(__('Quick Links')); ?></h4>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
                    <a href="#getting-started" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Getting Started')); ?></a>
                    <a href="#student-management" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Student Management')); ?></a>
                    <a href="#assessments" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Assessments')); ?></a>
                    <a href="#assessment-management" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Manage Assessments')); ?></a>
                    <a href="#mentoring" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Mentoring Visits')); ?></a>
                    <a href="#mentoring-management" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Manage Mentoring')); ?></a>
                    <a href="#reports" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Reports')); ?></a>
                    <a href="#bulk-import" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Bulk Import')); ?></a>
                    <a href="#resources" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Resources')); ?></a>
                    <a href="#workflows" class="text-indigo-600 hover:text-indigo-800 text-sm">→ <?php echo e(__('Common Workflows')); ?></a>
                </div>
            </div>

            <!-- User Roles Section -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mb-6">
                <div class="p-6">
                    <h4 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('User Roles & Permissions')); ?></h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div class="border rounded-lg p-4">
                            <h5 class="font-medium text-gray-900 mb-2"><?php echo e(__('Administrator')); ?></h5>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• <?php echo e(__('Full system access')); ?></li>
                                <li>• <?php echo e(__('Manage all users')); ?></li>
                                <li>• <?php echo e(__('Assign mentors to schools')); ?></li>
                                <li>• <?php echo e(__('Access all reports')); ?></li>
                            </ul>
                        </div>
                        <div class="border rounded-lg p-4">
                            <h5 class="font-medium text-gray-900 mb-2"><?php echo e(__('Teacher')); ?></h5>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• <?php echo e(__('Manage own students')); ?></li>
                                <li>• <?php echo e(__('Conduct assessments')); ?></li>
                                <li>• <?php echo e(__('View class reports')); ?></li>
                                <li>• <?php echo e(__('Access resources')); ?></li>
                            </ul>
                        </div>
                        <div class="border rounded-lg p-4">
                            <h5 class="font-medium text-gray-900 mb-2"><?php echo e(__('Mentor')); ?></h5>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• <?php echo e(__('Visit assigned schools')); ?></li>
                                <li>• <?php echo e(__('Verify assessments')); ?></li>
                                <li>• <?php echo e(__('Document visits')); ?></li>
                                <li>• <?php echo e(__('View school reports')); ?></li>
                            </ul>
                        </div>
                        <div class="border rounded-lg p-4">
                            <h5 class="font-medium text-gray-900 mb-2"><?php echo e(__('Viewer')); ?></h5>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• <?php echo e(__('Read-only access')); ?></li>
                                <li>• <?php echo e(__('View reports')); ?></li>
                                <li>• <?php echo e(__('Export data')); ?></li>
                                <li>• <?php echo e(__('No editing rights')); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step-by-Step Guides -->
            <div class="space-y-6">
                <!-- Getting Started -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="getting-started">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                            </svg>
                            <?php echo e(__('Getting Started')); ?>

                        </h4>
                        <div class="space-y-4">
                            <details class="group" open>
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('How to Log In')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to the login page')); ?></li>
                                        <li><?php echo e(__('Enter your email address')); ?></li>
                                        <li><?php echo e(__('Enter your password')); ?></li>
                                        <li><?php echo e(__('Click "Login" button')); ?></li>
                                    </ol>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Note: If you forgot your password, click "Forgot Password" link below the login form')); ?></p>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Update Your Profile')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Click your name in the top right corner')); ?></li>
                                        <li><?php echo e(__('Select "My Profile" from dropdown')); ?></li>
                                        <li><?php echo e(__('Update your information:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Name')); ?></li>
                                                <li><?php echo e(__('Email')); ?></li>
                                                <li><?php echo e(__('Phone number')); ?></li>
                                                <li><?php echo e(__('Profile photo (max 5MB)')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Click "Save" button')); ?></li>
                                    </ol>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Student Management -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="student-management">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                            </svg>
                            <?php echo e(__('Student Management')); ?>

                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Add a New Student')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Students" menu')); ?></li>
                                        <li><?php echo e(__('Click "Add New Student" button')); ?></li>
                                        <li><?php echo e(__('Fill in required information:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Student ID')); ?></li>
                                                <li><?php echo e(__('Full name')); ?></li>
                                                <li><?php echo e(__('Grade (4 or 5 only)')); ?></li>
                                                <li><?php echo e(__('Gender')); ?></li>
                                                <li><?php echo e(__('Date of birth')); ?></li>
                                                <li><?php echo e(__('School')); ?></li>
                                                <li><?php echo e(__('Class/Section')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Upload student photo (optional)')); ?></li>
                                        <li><?php echo e(__('Click "Save" button')); ?></li>
                                    </ol>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Important: Only Grade 4 and 5 students can be added')); ?></p>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Select Students for Assessments')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('For Midline/Endline Assessments:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Assessments" page')); ?></li>
                                        <li><?php echo e(__('Click "Select Students" button')); ?></li>
                                        <li><?php echo e(__('Choose "Midline" or "Endline" tab')); ?></li>
                                        <li><?php echo e(__('Use filters to find students:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Search by name')); ?></li>
                                                <li><?php echo e(__('Filter by school')); ?></li>
                                                <li><?php echo e(__('Filter by grade')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Select students using checkboxes')); ?></li>
                                        <li><?php echo e(__('Click "Save Selection"')); ?></li>
                                    </ol>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Note: Baseline assessments include all students automatically')); ?></p>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Assessments -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="assessments">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
                            </svg>
                            <?php echo e(__('Assessments')); ?>

                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Create an Assessment')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Assessments" page')); ?></li>
                                        <li><?php echo e(__('Click "New Assessment" button')); ?></li>
                                        <li><?php echo e(__('Select assessment details:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Subject (Khmer or Math)')); ?></li>
                                                <li><?php echo e(__('Assessment Cycle:')); ?>

                                                    <ul class="list-circle list-inside ml-4">
                                                        <li><?php echo e(__('Baseline (all students)')); ?></li>
                                                        <li><?php echo e(__('Midline (selected students)')); ?></li>
                                                        <li><?php echo e(__('Endline (selected students)')); ?></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Enter scores for each student')); ?></li>
                                        <li><?php echo e(__('Click "Save Assessment"')); ?></li>
                                    </ol>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Assessment Cycles Explained')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <div class="space-y-3">
                                        <div>
                                            <p class="font-medium"><?php echo e(__('Baseline Assessment:')); ?></p>
                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Initial assessment at start of year')); ?></li>
                                                <li><?php echo e(__('All students participate')); ?></li>
                                                <li><?php echo e(__('Establishes starting level')); ?></li>
                                            </ul>
                                        </div>
                                        <div>
                                            <p class="font-medium"><?php echo e(__('Midline Assessment:')); ?></p>
                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Mid-year progress check')); ?></li>
                                                <li><?php echo e(__('Only selected students')); ?></li>
                                                <li><?php echo e(__('Tracks improvement')); ?></li>
                                            </ul>
                                        </div>
                                        <div>
                                            <p class="font-medium"><?php echo e(__('Endline Assessment:')); ?></p>
                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Final assessment')); ?></li>
                                                <li><?php echo e(__('Only selected students')); ?></li>
                                                <li><?php echo e(__('Measures total progress')); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Setting Assessment Dates for Schools')); ?> <span class="text-xs text-gray-500">(<?php echo e(__('Admin only')); ?>)</span></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Schools" page')); ?></li>
                                        <li><?php echo e(__('Click on a school name to view details')); ?></li>
                                        <li><?php echo e(__('Click "Edit" button on the school page')); ?></li>
                                        <li><?php echo e(__('Set assessment period dates:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Baseline Assessment Start Date')); ?></li>
                                                <li><?php echo e(__('Baseline Assessment End Date')); ?></li>
                                                <li><?php echo e(__('Midline Assessment Start Date')); ?></li>
                                                <li><?php echo e(__('Midline Assessment End Date')); ?></li>
                                                <li><?php echo e(__('Endline Assessment Start Date')); ?></li>
                                                <li><?php echo e(__('Endline Assessment End Date')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Click "Update School" to save')); ?></li>
                                    </ol>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Note: These dates determine when teachers can conduct each type of assessment for the school')); ?></p>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Assessment Management -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="assessment-management">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <?php echo e(__('Manage Assessments')); ?> <span class="text-sm text-gray-500 ml-2">(<?php echo e(__('Admin only')); ?>)</span>
                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Lock/Unlock Assessments')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Manage Assessments" page (Admin menu)')); ?></li>
                                        <li><?php echo e(__('View list of all assessments with their lock status')); ?></li>
                                        <li><?php echo e(__('Find the assessment you want to manage')); ?></li>
                                        <li><?php echo e(__('Click the lock/unlock button:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Red lock icon = Assessment is locked (no edits allowed)')); ?></li>
                                                <li><?php echo e(__('Green unlock icon = Assessment is unlocked (can be edited)')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Confirm the action when prompted')); ?></li>
                                    </ol>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Note: Locking an assessment prevents any changes to scores or student data')); ?></p>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Filter and Search Assessments')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Available filters:')); ?></p>
                                    <ul class="list-disc list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('By School - Select specific school')); ?></li>
                                        <li><?php echo e(__('By Teacher - Filter by teacher name')); ?></li>
                                        <li><?php echo e(__('By Subject - Khmer or Math')); ?></li>
                                        <li><?php echo e(__('By Cycle - Baseline, Midline, or Endline')); ?></li>
                                        <li><?php echo e(__('By Lock Status - Show locked or unlocked only')); ?></li>
                                        <li><?php echo e(__('By Date Range - Filter by assessment date')); ?></li>
                                    </ul>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Tip: Combine multiple filters for precise results')); ?></p>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Bulk Actions on Assessments')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Available bulk actions:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Select multiple assessments using checkboxes')); ?></li>
                                        <li><?php echo e(__('Choose bulk action from dropdown:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Lock selected assessments')); ?></li>
                                                <li><?php echo e(__('Unlock selected assessments')); ?></li>
                                                <li><?php echo e(__('Export selected assessments')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Click "Apply" to execute the action')); ?></li>
                                        <li><?php echo e(__('Confirm when prompted')); ?></li>
                                    </ol>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('When to Lock Assessments')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Best practices:')); ?></p>
                                    <ul class="list-disc list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Lock baseline assessments after all students are assessed')); ?></li>
                                        <li><?php echo e(__('Lock midline assessments before starting endline')); ?></li>
                                        <li><?php echo e(__('Lock all assessments before generating final reports')); ?></li>
                                        <li><?php echo e(__('Lock assessments after verification by mentors')); ?></li>
                                        <li><?php echo e(__('Keep assessments unlocked during active assessment periods')); ?></li>
                                    </ul>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Important: Locked assessments cannot be edited by anyone, including admins')); ?></p>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Mentoring Visits -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="mentoring">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                            <?php echo e(__('Mentoring Visits')); ?> <span class="text-sm text-gray-500 ml-2">(<?php echo e(__('For Mentors')); ?>)</span>
                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('School Assignment for Mentors')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('For Administrators:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Users" page')); ?></li>
                                        <li><?php echo e(__('Click on a mentor user')); ?></li>
                                        <li><?php echo e(__('Click "Assign Schools" button')); ?></li>
                                        <li><?php echo e(__('Select schools with checkboxes')); ?></li>
                                        <li><?php echo e(__('Click "Save School Assignments"')); ?></li>
                                    </ol>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Note: Mentors can only visit assigned schools')); ?></p>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Log a Mentoring Visit')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Mentoring Log" page')); ?></li>
                                        <li><?php echo e(__('Click "Log Visit" button')); ?></li>
                                        <li><?php echo e(__('Fill in visit details:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Visit date')); ?></li>
                                                <li><?php echo e(__('Select school (only assigned schools shown)')); ?></li>
                                                <li><?php echo e(__('Select teacher')); ?></li>
                                                <li><?php echo e(__('Observation notes')); ?></li>
                                                <li><?php echo e(__('Action plan')); ?></li>
                                                <li><?php echo e(__('Follow-up requirements')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Complete questionnaire sections')); ?></li>
                                        <li><?php echo e(__('Upload photos (optional)')); ?></li>
                                        <li><?php echo e(__('Submit visit log')); ?></li>
                                    </ol>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Mentoring Management -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="mentoring-management">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                            </svg>
                            <?php echo e(__('Manage Mentoring')); ?> <span class="text-sm text-gray-500 ml-2">(<?php echo e(__('Admin only')); ?>)</span>
                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('View All Mentoring Visits')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Features:')); ?></p>
                                    <ul class="list-disc list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('View all mentoring visits across all schools')); ?></li>
                                        <li><?php echo e(__('See visit details including:')); ?>

                                            <ul class="list-circle list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Mentor name and contact')); ?></li>
                                                <li><?php echo e(__('School visited')); ?></li>
                                                <li><?php echo e(__('Teacher observed')); ?></li>
                                                <li><?php echo e(__('Visit date and duration')); ?></li>
                                                <li><?php echo e(__('Observation notes')); ?></li>
                                                <li><?php echo e(__('Action plans')); ?></li>
                                                <li><?php echo e(__('Photos uploaded')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Track follow-up requirements')); ?></li>
                                    </ul>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Filter Mentoring Visits')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Available filters:')); ?></p>
                                    <ul class="list-disc list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('By Mentor - Select specific mentor')); ?></li>
                                        <li><?php echo e(__('By School - Filter by school name')); ?></li>
                                        <li><?php echo e(__('By District - Show visits in specific district')); ?></li>
                                        <li><?php echo e(__('By Date Range - Filter by visit date')); ?></li>
                                        <li><?php echo e(__('By Follow-up Status - Show visits requiring follow-up')); ?></li>
                                        <li><?php echo e(__('By Teacher - Filter by teacher observed')); ?></li>
                                    </ul>
                                    <p class="text-xs text-gray-500 mt-2"><?php echo e(__('Tip: Export filtered results for reporting')); ?></p>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Mentoring Analytics')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Available metrics:')); ?></p>
                                    <ul class="list-disc list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Total visits per month/quarter')); ?></li>
                                        <li><?php echo e(__('Average visits per school')); ?></li>
                                        <li><?php echo e(__('Mentor performance metrics')); ?></li>
                                        <li><?php echo e(__('Schools with most/least visits')); ?></li>
                                        <li><?php echo e(__('Follow-up completion rate')); ?></li>
                                        <li><?php echo e(__('Time between visits per school')); ?></li>
                                    </ul>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Export Mentoring Data')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Manage Mentoring" page')); ?></li>
                                        <li><?php echo e(__('Apply desired filters')); ?></li>
                                        <li><?php echo e(__('Click "Export" button')); ?></li>
                                        <li><?php echo e(__('Choose export format:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('CSV - For data analysis')); ?></li>
                                                <li><?php echo e(__('Excel - For formatted reports')); ?></li>
                                                <li><?php echo e(__('PDF - For presentation')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Download the file')); ?></li>
                                    </ol>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Mentor Assignment Overview')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('View and manage:')); ?></p>
                                    <ul class="list-disc list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('List of all mentors and their assigned schools')); ?></li>
                                        <li><?php echo e(__('Quick reassignment of schools')); ?></li>
                                        <li><?php echo e(__('Mentor workload balancing')); ?></li>
                                        <li><?php echo e(__('Coverage gaps identification')); ?></li>
                                        <li><?php echo e(__('Historical assignment tracking')); ?></li>
                                    </ul>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Reports -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="reports">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                            </svg>
                            <?php echo e(__('Reports')); ?>

                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Available Reports')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <div class="space-y-3">
                                        <div>
                                            <p class="font-medium"><?php echo e(__('Student Performance Report:')); ?></p>
                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Individual student progress')); ?></li>
                                                <li><?php echo e(__('Accessible by all roles')); ?></li>
                                            </ul>
                                        </div>
                                        <div>
                                            <p class="font-medium"><?php echo e(__('Progress Tracking Report:')); ?></p>
                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Baseline to endline improvement')); ?></li>
                                                <li><?php echo e(__('Accessible by all roles')); ?></li>
                                            </ul>
                                        </div>
                                        <div>
                                            <p class="font-medium"><?php echo e(__('School Comparison Report:')); ?></p>
                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Performance across schools')); ?></li>
                                                <li><?php echo e(__('Admin and Mentors only')); ?></li>
                                            </ul>
                                        </div>
                                        <div>
                                            <p class="font-medium"><?php echo e(__('Mentoring Impact Report:')); ?></p>
                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Correlation between visits and improvement')); ?></li>
                                                <li><?php echo e(__('Admin and Mentors only')); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Generate and Export Reports')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Reports" page')); ?></li>
                                        <li><?php echo e(__('Select report type')); ?></li>
                                        <li><?php echo e(__('Apply filters:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Date range')); ?></li>
                                                <li><?php echo e(__('School')); ?></li>
                                                <li><?php echo e(__('Grade (4 or 5)')); ?></li>
                                                <li><?php echo e(__('Subject')); ?></li>
                                                <li><?php echo e(__('Assessment cycle')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Click "Generate Report"')); ?></li>
                                        <li><?php echo e(__('To export: Click "Export" button')); ?></li>
                                    </ol>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Bulk Import -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="bulk-import">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                            </svg>
                            <?php echo e(__('Bulk Import')); ?>

                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Import Students')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Students" page')); ?></li>
                                        <li><?php echo e(__('Click "Import Students" button')); ?></li>
                                        <li><?php echo e(__('Download the CSV template')); ?></li>
                                        <li><?php echo e(__('Fill in the template with:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Student ID')); ?></li>
                                                <li><?php echo e(__('Name')); ?></li>
                                                <li><?php echo e(__('Grade (4 or 5)')); ?></li>
                                                <li><?php echo e(__('Gender')); ?></li>
                                                <li><?php echo e(__('Date of birth')); ?></li>
                                                <li><?php echo e(__('School')); ?></li>
                                                <li><?php echo e(__('Class')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Save as CSV file')); ?></li>
                                        <li><?php echo e(__('Upload the file')); ?></li>
                                        <li><?php echo e(__('Review import results')); ?></li>
                                    </ol>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Import Users')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?> <span class="text-xs text-gray-500">(<?php echo e(__('Admin only')); ?>)</span></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Users" page')); ?></li>
                                        <li><?php echo e(__('Click "Import Users" button')); ?></li>
                                        <li><?php echo e(__('Download the CSV template')); ?></li>
                                        <li><?php echo e(__('Fill in user data:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Name')); ?></li>
                                                <li><?php echo e(__('Email')); ?></li>
                                                <li><?php echo e(__('Password')); ?></li>
                                                <li><?php echo e(__('Role (admin/teacher/mentor/viewer)')); ?></li>
                                                <li><?php echo e(__('School')); ?></li>
                                                <li><?php echo e(__('Phone number')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Upload the completed CSV')); ?></li>
                                        <li><?php echo e(__('Review import results')); ?></li>
                                    </ol>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Import Schools')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?> <span class="text-xs text-gray-500">(<?php echo e(__('Admin only')); ?>)</span></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Schools" page')); ?></li>
                                        <li><?php echo e(__('Click "Import Schools" button')); ?></li>
                                        <li><?php echo e(__('Download the CSV template')); ?></li>
                                        <li><?php echo e(__('Fill in school data:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('School name')); ?></li>
                                                <li><?php echo e(__('Province')); ?></li>
                                                <li><?php echo e(__('District')); ?></li>
                                                <li><?php echo e(__('Commune')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Upload the completed CSV')); ?></li>
                                        <li><?php echo e(__('Review import results')); ?></li>
                                    </ol>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Resources -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="resources">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                            </svg>
                            <?php echo e(__('Resource Management')); ?>

                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Add Resources')); ?> <span class="text-xs text-gray-500">(<?php echo e(__('Admin only')); ?>)</span></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Manage Resources" (Admin menu)')); ?></li>
                                        <li><?php echo e(__('Click "Add Resource" button')); ?></li>
                                        <li><?php echo e(__('Fill in resource details:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Title')); ?></li>
                                                <li><?php echo e(__('Description')); ?></li>
                                                <li><?php echo e(__('Type (YouTube/Excel/PDF)')); ?></li>
                                                <li><?php echo e(__('For YouTube: Enter URL')); ?></li>
                                                <li><?php echo e(__('For Files: Upload file')); ?></li>
                                                <li><?php echo e(__('Set visibility (Public/Private)')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Save the resource')); ?></li>
                                    </ol>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Access Resources')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Go to "Resources" page')); ?></li>
                                        <li><?php echo e(__('Browse available resources')); ?></li>
                                        <li><?php echo e(__('Use type filter to find specific resources')); ?></li>
                                        <li><?php echo e(__('Click to view or download')); ?></li>
                                    </ol>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>

                <!-- Common Workflows -->
                <div class="bg-white overflow-hidden shadow-sm rounded-lg" id="workflows">
                    <div class="p-6">
                        <h4 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                            </svg>
                            <?php echo e(__('Common Workflows')); ?>

                        </h4>
                        <div class="space-y-4">
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('Setting Up a New School Year')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Administrator Tasks:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Import or create schools')); ?></li>
                                        <li><?php echo e(__('Import or create users (teachers and mentors)')); ?></li>
                                        <li><?php echo e(__('Assign schools to mentors')); ?></li>
                                        <li><?php echo e(__('Import students')); ?></li>
                                    </ol>
                                    <p class="font-medium mt-3"><?php echo e(__('Teacher Tasks:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Verify student lists')); ?></li>
                                        <li><?php echo e(__('Conduct baseline assessments for all students')); ?></li>
                                    </ol>
                                    <p class="font-medium mt-3"><?php echo e(__('Mid-Year Tasks:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Select students for midline assessments')); ?></li>
                                        <li><?php echo e(__('Conduct midline assessments')); ?></li>
                                    </ol>
                                    <p class="font-medium mt-3"><?php echo e(__('End-Year Tasks:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Select students for endline assessments')); ?></li>
                                        <li><?php echo e(__('Conduct endline assessments')); ?></li>
                                    </ol>
                                </div>
                            </details>
                            <details class="group">
                                <summary class="cursor-pointer text-sm font-medium text-gray-900 hover:text-indigo-600"><?php echo e(__('End of Year Process')); ?></summary>
                                <div class="mt-2 text-sm text-gray-600 pl-4 space-y-2">
                                    <p class="font-medium"><?php echo e(__('Steps:')); ?></p>
                                    <ol class="list-decimal list-inside space-y-1 ml-2">
                                        <li><?php echo e(__('Export all assessment data')); ?></li>
                                        <li><?php echo e(__('Generate final reports:')); ?>

                                            <ul class="list-disc list-inside ml-4 mt-1">
                                                <li><?php echo e(__('Student Performance Report')); ?></li>
                                                <li><?php echo e(__('Progress Tracking Report')); ?></li>
                                                <li><?php echo e(__('School Comparison Report')); ?></li>
                                                <li><?php echo e(__('Mentoring Impact Report')); ?></li>
                                            </ul>
                                        </li>
                                        <li><?php echo e(__('Archive the data')); ?></li>
                                        <li><?php echo e(__('Prepare for next year')); ?></li>
                                    </ol>
                                </div>
                            </details>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Tips -->
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
                <h4 class="font-medium text-blue-900 mb-2"><?php echo e(__('Quick Tips')); ?></h4>
                <ul class="text-sm text-blue-800 space-y-1">
                    <li>• <?php echo e(__('For new mentors: First get schools assigned by an administrator before starting any activities')); ?></li>
                    <li>• <?php echo e(__('For assessment planning: Select students for midline/endline before the assessment period begins')); ?></li>
                    <li>• <?php echo e(__('Regular backups: Export data regularly using the export features')); ?></li>
                    <li>• <?php echo e(__('Filter usage: Clear filters by submitting empty filter forms to see all data')); ?></li>
                    <li>• <?php echo e(__('Language: Switch between Khmer and English using the language selector in navigation')); ?></li>
                </ul>
            </div>

            <!-- Contact Support -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mt-6">
                <div class="p-6">
                    <h4 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('Need More Help?')); ?></h4>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="text-center">
                            <div class="mx-auto h-12 w-12 text-indigo-600 mb-3">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                            </div>
                            <h5 class="font-medium text-gray-900 mb-1"><?php echo e(__('Email Support')); ?></h5>
                            <p class="text-sm text-gray-600">chhinhs@gmail.com</p>
                        </div>
                        <div class="text-center">
                            <div class="mx-auto h-12 w-12 text-indigo-600 mb-3">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path>
                                </svg>
                            </div>
                            <h5 class="font-medium text-gray-900 mb-1"><?php echo e(__('Telegram Support')); ?></h5>
                            <a href="https://t.me/chhinh_sovath" target="_blank" class="text-sm text-indigo-600 hover:text-indigo-800">@chhinh_sovath</a>
                        </div>
                        <div class="text-center">
                            <div class="mx-auto h-12 w-12 text-indigo-600 mb-3">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <h5 class="font-medium text-gray-900 mb-1"><?php echo e(__('Support Hours')); ?></h5>
                            <p class="text-sm text-gray-600"><?php echo e(__('Mon-Fri: 8AM-5PM')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/help/index.blade.php ENDPATH**/ ?>