<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('administration.Administration')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="w-full sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-6"><?php echo e(__('administration.System Administration')); ?></h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <!-- User Management -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-blue-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Manage Users')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Add, edit, and manage user accounts and permissions')); ?></p>
                            <a href="<?php echo e(route('users.index')); ?>" class="text-blue-600 hover:text-blue-800 font-medium">
                                <?php echo e(__('administration.Go to User Management')); ?> →
                            </a>
                        </div>

                        <!-- Import Users -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-green-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Import Users')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Bulk import users from Excel or CSV files')); ?></p>
                            <a href="<?php echo e(route('users.bulk-import-form')); ?>" class="text-green-600 hover:text-green-800 font-medium">
                                <?php echo e(__('administration.Import Users')); ?> →
                            </a>
                        </div>

                        <!-- Import Students -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-purple-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Import Students')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Bulk import student data from spreadsheets')); ?></p>
                            <a href="<?php echo e(route('students.bulk-import-form')); ?>" class="text-purple-600 hover:text-purple-800 font-medium">
                                <?php echo e(__('administration.Import Students')); ?> →
                            </a>
                        </div>

                        <!-- School Management -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-indigo-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Manage Schools')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Add and manage school information')); ?></p>
                            <a href="<?php echo e(route('schools.index')); ?>" class="text-indigo-600 hover:text-indigo-800 font-medium">
                                <?php echo e(__('administration.Go to School Management')); ?> →
                            </a>
                        </div>

                        <!-- Assessment Dates -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-yellow-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Assessment Dates')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Configure assessment dates for schools')); ?></p>
                            <a href="<?php echo e(route('schools.assessment-dates')); ?>" class="text-yellow-600 hover:text-yellow-800 font-medium">
                                <?php echo e(__('administration.Manage Dates')); ?> →
                            </a>
                        </div>

                        <!-- Assessment Management -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-red-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Assessment Management')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Lock/unlock assessments and manage data')); ?></p>
                            <a href="<?php echo e(route('assessment-management.index')); ?>" class="text-red-600 hover:text-red-800 font-medium">
                                <?php echo e(__('administration.Manage Assessments')); ?> →
                            </a>
                        </div>

                        <!-- Mentoring Management -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-teal-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Mentoring Management')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Manage mentoring visits and activities')); ?></p>
                            <a href="<?php echo e(route('assessment-management.mentoring-visits')); ?>" class="text-teal-600 hover:text-teal-800 font-medium">
                                <?php echo e(__('administration.Manage Mentoring')); ?> →
                            </a>
                        </div>

                        <!-- Resource Management -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-orange-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Manage Resources')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Upload and manage educational resources')); ?></p>
                            <a href="<?php echo e(route('resources.index')); ?>" class="text-orange-600 hover:text-orange-800 font-medium">
                                <?php echo e(__('administration.Manage Resources')); ?> →
                            </a>
                        </div>

                        <!-- Settings -->
                        <div class="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors">
                            <div class="flex items-center mb-4">
                                <svg class="w-8 h-8 text-gray-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                </svg>
                                <h4 class="font-semibold text-lg"><?php echo e(__('administration.Settings')); ?></h4>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e(__('administration.Configure system settings and preferences')); ?></p>
                            <a href="<?php echo e(route('settings.index')); ?>" class="text-gray-600 hover:text-gray-800 font-medium">
                                <?php echo e(__('administration.Go to Settings')); ?> →
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/administration/index.blade.php ENDPATH**/ ?>