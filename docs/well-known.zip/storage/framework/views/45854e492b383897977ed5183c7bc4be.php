<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['column', 'currentSort' => null, 'currentOrder' => 'asc']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['column', 'currentSort' => null, 'currentOrder' => 'asc']); ?>
<?php foreach (array_filter((['column', 'currentSort' => null, 'currentOrder' => 'asc']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $isActive = $currentSort === $column;
    $nextOrder = $isActive && $currentOrder === 'asc' ? 'desc' : 'asc';
    $icon = $isActive ? ($currentOrder === 'asc' ? '↑' : '↓') : '↕';
    
    // Preserve all existing query parameters and merge with sort parameters
    $queryParams = request()->query();
    $queryParams['sort'] = $column;
    $queryParams['order'] = $nextOrder;
?>

<a href="<?php echo e(request()->fullUrlWithQuery($queryParams)); ?>" 
   class="flex items-center space-x-1 text-gray-700 hover:text-gray-900 transition-colors duration-150">
    <span><?php echo e($slot); ?></span>
    <span class="text-gray-400 <?php echo e($isActive ? 'text-gray-700' : ''); ?>"><?php echo e($icon); ?></span>
</a><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/components/sortable-header.blade.php ENDPATH**/ ?>