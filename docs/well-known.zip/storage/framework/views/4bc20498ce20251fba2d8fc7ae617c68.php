<!DOCTYPE html>
<html>
<head>
    <title>Locale Test</title>
</head>
<body>
    <h1>Locale Debug Information</h1>
    
    <p><strong>Current Locale:</strong> <?php echo e(app()->getLocale()); ?></p>
    <p><strong>Config Locale:</strong> <?php echo e(config('app.locale')); ?></p>
    <p><strong>Session Locale:</strong> <?php echo e(session('locale', 'not set')); ?></p>
    <p><strong>Cookie Locale:</strong> <?php echo e(request()->cookie('locale', 'not set')); ?></p>
    
    <h2>Translation Test</h2>
    <p><strong>__('Assessments'):</strong> <?php echo e(__('Assessments')); ?></p>
    <p><strong>__('Students'):</strong> <?php echo e(__('Students')); ?></p>
    <p><strong>__('Dashboard'):</strong> <?php echo e(__('Dashboard')); ?></p>
    <p><strong>trans('Assessments'):</strong> <?php echo e(trans('Assessments')); ?></p>
    <p><strong>Lang::get('Assessments'):</strong> <?php echo e(Lang::get('Assessments')); ?></p>
    
    <h2>Language Files</h2>
    <p><strong>km.json exists (lang/):</strong> <?php echo e(file_exists(base_path('lang/km.json')) ? 'Yes' : 'No'); ?></p>
    <p><strong>km.json exists (resources/lang/):</strong> <?php echo e(file_exists(resource_path('lang/km.json')) ? 'Yes' : 'No'); ?></p>
    <p><strong>Lang path:</strong> <?php echo e(app()->langPath()); ?></p>
    <p><strong>Resource path:</strong> <?php echo e(resource_path('lang')); ?></p>
    
    <h2>JSON Translation Test</h2>
    <?php
        $translations = json_decode(file_get_contents(resource_path('lang/km.json')), true);
    ?>
    <p><strong>Loaded translations count:</strong> <?php echo e(count($translations)); ?></p>
    <p><strong>Sample: Assessments in km.json:</strong> <?php echo e($translations['Assessments'] ?? 'NOT FOUND'); ?></p>
    
    <h2><?php echo e(__("Actions")); ?></h2>
    <p>
        <a href="<?php echo e(url('/language/en')); ?>" style="margin-right: 10px;">Switch to English</a>
        <a href="<?php echo e(url('/language/km')); ?>">Switch to Khmer</a>
    </p>
</body>
</html><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/test-locale.blade.php ENDPATH**/ ?>