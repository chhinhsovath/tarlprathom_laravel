<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-6">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Progress Tracking Report')); ?></h3>
                        <a href="<?php echo e(route('reports.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                            ← <?php echo e(__('Back to Reports')); ?>

                        </a>
                    </div>
                    
                    <!-- Filters -->
                    <form method="GET" action="<?php echo e(route('reports.progress-tracking')); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label for="school_id" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('School')); ?></label>
                            <select name="school_id" id="school_id" class="w-full h-11 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value=""><?php echo e(__('All Schools')); ?></option>
                                <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($school->id); ?>" <?php echo e($schoolId == $school->id ? 'selected' : ''); ?>>
                                        <?php echo e($school->school_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="subject" class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('Subject')); ?></label>
                            <select name="subject" id="subject" class="w-full h-11 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="khmer" <?php echo e($subject == 'khmer' ? 'selected' : ''); ?>><?php echo e(__('Khmer')); ?></option>
                                <option value="math" <?php echo e($subject == 'math' ? 'selected' : ''); ?>><?php echo e(__('Math')); ?></option>
                            </select>
                        </div>
                        
                        <div class="flex items-end">
                            <button type="submit" class="w-full h-11 inline-flex justify-center items-center px-4 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition">
                                <?php echo e(__('Apply Filters')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Understanding Progress Tracking -->
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-blue-800"><?php echo e(__('Understanding Progress Tracking')); ?></h3>
                        <div class="mt-2 text-sm text-blue-700">
                            <p class="mb-2"><?php echo e(__('This report tracks individual student learning progress by comparing their baseline assessment with their most recent assessment (midline or endline). It shows:')); ?></p>
                            <ul class="list-disc list-inside space-y-1">
                                <li><?php echo e(__('Students who improved to higher skill levels')); ?></li>
                                <li><?php echo e(__('Students who maintained their skill level')); ?></li>
                                <li><?php echo e(__('Students whose performance declined')); ?></li>
                                <li><?php echo e(__('Score changes between assessment cycles')); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- How Progress is Calculated -->
            <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-green-800"><?php echo e(__('How Progress is Calculated')); ?></h3>
                        <div class="mt-2 text-sm text-green-700">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <h4 class="font-semibold mb-1"><?php echo e(__('Level Change')); ?>:</h4>
                                    <ul class="list-disc list-inside text-xs space-y-0.5">
                                        <li><?php echo e(__('Compares skill levels between baseline and latest assessment')); ?></li>
                                        <li><?php echo e(__('Positive number = moved up levels (improved)')); ?></li>
                                        <li><?php echo e(__('Zero = stayed at same level (maintained)')); ?></li>
                                        <li><?php echo e(__('Negative number = moved down levels (declined)')); ?></li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold mb-1"><?php echo e(__('Score Change')); ?>:</h4>
                                    <ul class="list-disc list-inside text-xs space-y-0.5">
                                        <li><?php echo e(__('Difference between latest score and baseline score')); ?></li>
                                        <li><?php echo e(__('Positive = score increased')); ?></li>
                                        <li><?php echo e(__('Zero = score stayed the same')); ?></li>
                                        <li><?php echo e(__('Negative = score decreased')); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Current Selection Info -->
            <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-gray-800"><?php echo e(__('Current View')); ?></h3>
                        <p class="text-sm text-gray-600 mt-1">
                            <?php echo e(__('Tracking progress in')); ?> <strong><?php echo e(ucfirst($subject)); ?></strong>
                            <?php if($schoolId): ?>
                                <?php echo e(__('for')); ?> <strong><?php echo e($schools->find($schoolId)->name ?? __('Selected School')); ?></strong>
                            <?php else: ?>
                                <?php echo e(__('across all accessible schools')); ?>

                            <?php endif; ?>
                            <br>
                            <span class="text-xs"><?php echo e(__('Only students with both baseline and follow-up assessments are included')); ?></span>
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Progress Summary -->
            <?php if(count($progressData) > 0): ?>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Progress Summary')); ?> - <?php echo e(ucfirst($subject)); ?></h4>
                    
                    <!-- Summary Cards Explanation -->
                    <div class="mb-4 p-3 bg-gray-50 rounded-lg text-sm text-gray-600">
                        <p><strong><?php echo e(__('Summary Cards')); ?>:</strong> <?php echo e(__('Each card shows the count and percentage of students in each progress category. The average score change shows the overall trend across all students.')); ?></p>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                        <?php
                            $totalStudents = count($progressData);
                            $improved = collect($progressData)->where('level_improved', '>', 0)->count();
                            $maintained = collect($progressData)->where('level_improved', '=', 0)->count();
                            $declined = collect($progressData)->where('level_improved', '<', 0)->count();
                            $avgLevelChange = collect($progressData)->avg('level_improved');
                        ?>
                        
                        <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                            <div class="text-2xl font-bold text-green-700"><?php echo e($improved); ?></div>
                            <div class="text-sm text-green-600"><?php echo e(__('Students Improved')); ?></div>
                            <div class="text-xs text-green-500"><?php echo e($totalStudents > 0 ? number_format(($improved / $totalStudents) * 100, 1) : 0); ?>% <?php echo e(__('of total')); ?></div>
                            <div class="text-xs text-green-400 mt-1"><?php echo e(__('Moved to higher skill levels')); ?></div>
                        </div>
                        
                        <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                            <div class="text-2xl font-bold text-blue-700"><?php echo e($maintained); ?></div>
                            <div class="text-sm text-blue-600"><?php echo e(__('Students Maintained')); ?></div>
                            <div class="text-xs text-blue-500"><?php echo e($totalStudents > 0 ? number_format(($maintained / $totalStudents) * 100, 1) : 0); ?>% <?php echo e(__('of total')); ?></div>
                            <div class="text-xs text-blue-400 mt-1"><?php echo e(__('Stayed at same skill level')); ?></div>
                        </div>
                        
                        <div class="bg-red-50 p-4 rounded-lg border border-red-200">
                            <div class="text-2xl font-bold text-red-700"><?php echo e($declined); ?></div>
                            <div class="text-sm text-red-600"><?php echo e(__('Students Declined')); ?></div>
                            <div class="text-xs text-red-500"><?php echo e($totalStudents > 0 ? number_format(($declined / $totalStudents) * 100, 1) : 0); ?>% <?php echo e(__('of total')); ?></div>
                            <div class="text-xs text-red-400 mt-1"><?php echo e(__('Moved to lower skill levels')); ?></div>
                        </div>
                        
                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-200">
                            <div class="text-2xl font-bold text-purple-700"><?php echo e($avgScoreChange >= 0 ? '+' : ''); ?><?php echo e(number_format($avgScoreChange, 1)); ?></div>
                            <div class="text-sm text-purple-600"><?php echo e(__('Avg Score Change')); ?></div>
                            <div class="text-xs text-purple-400 mt-1">
                                <?php if($avgScoreChange > 0): ?>
                                    <?php echo e(__('Overall improvement trend')); ?>

                                <?php elseif($avgScoreChange < 0): ?>
                                    <?php echo e(__('Overall decline trend')); ?>

                                <?php else: ?>
                                    <?php echo e(__('No overall change')); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Progress Visualization Explanation -->
                    <div class="mb-4 p-3 bg-gray-50 rounded-lg text-sm text-gray-600">
                        <p><strong><?php echo e(__('Progress Distribution Chart')); ?>:</strong> <?php echo e(__('This doughnut chart shows the proportion of students in each progress category. Larger green sections indicate more students improved, while larger red sections may indicate need for intervention.')); ?></p>
                    </div>
                    
                    <!-- Progress Visualization -->
                    <div class="relative" style="height: 300px;">
                        <canvas id="progressChart"></canvas>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Detailed Student Progress -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Individual Student Progress')); ?> - <?php echo e(ucfirst($subject)); ?></h4>
                    
                    <!-- Table Explanation -->
                    <div class="mb-4 p-3 bg-gray-50 rounded-lg text-sm text-gray-600">
                        <p class="font-medium mb-2"><?php echo e(__('Reading the Progress Table')); ?>:</p>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                            <div><strong><?php echo e(__('Baseline')); ?>:</strong> <?php echo e(__('Initial skill level and score when first assessed')); ?></div>
                            <div><strong><?php echo e(__('Latest')); ?>:</strong> <?php echo e(__('Most recent skill level and score (midline or endline)')); ?></div>
                            <div><strong><?php echo e(__('Level Change')); ?>:</strong> <?php echo e(__('Number of skill levels moved up (+) or down (-)')); ?></div>
                            <div><strong><?php echo e(__('Score Change')); ?>:</strong> <?php echo e(__('Numerical difference between latest and baseline scores')); ?></div>
                        </div>
                        <p class="mt-2 text-xs"><?php echo e(__('Students are sorted by level improvement (most improved first), then by score change.')); ?></p>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Student Name')); ?>

                                        <span class="normal-case text-gray-400" title="<?php echo e(__('Student name')); ?>">ⓘ</span>
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('School')); ?>

                                        <span class="normal-case text-gray-400" title="<?php echo e(__('School where student is enrolled')); ?>">ⓘ</span>
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Baseline')); ?>

                                        <span class="normal-case text-gray-400" title="<?php echo e(__('Initial assessment level and score')); ?>">ⓘ</span>
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Latest')); ?> (<?php echo e(__('Cycle')); ?>)
                                        <span class="normal-case text-gray-400" title="<?php echo e(__('Most recent assessment level and score')); ?>">ⓘ</span>
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Level Change')); ?>

                                        <span class="normal-case text-gray-400" title="<?php echo e(__('Change in skill levels (+ improved, - declined, = same)')); ?>">ⓘ</span>
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <?php echo e(__('Score Change')); ?>

                                        <span class="normal-case text-gray-400" title="<?php echo e(__('Numerical score difference (latest - baseline)')); ?>">ⓘ</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__empty_1 = true; $__currentLoopData = $progressData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo e($data['student']->name); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e($data['student']->school->name); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                            <?php echo e(__($data['baseline_level'])); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                            <?php echo e(__($data['latest_level'])); ?>

                                        </span>
                                        <div class="text-xs text-gray-400"><?php echo e(__(ucfirst($data['latest_cycle']))); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if($data['level_improved'] > 0): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                ↑ +<?php echo e($data['level_improved']); ?> <?php echo e($data['level_improved'] == 1 ? __('level') : __('levels')); ?>

                                            </span>
                                        <?php elseif($data['level_improved'] < 0): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                ↓ <?php echo e($data['level_improved']); ?> <?php echo e(abs($data['level_improved']) == 1 ? __('level') : __('levels')); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                                = <?php echo e(__('Same level')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if($data['level_improved'] > 0): ?>
                                            <span class="text-green-600 font-medium">+<?php echo e($data['level_improved']); ?> <?php echo e(__('levels')); ?></span>
                                        <?php elseif($data['level_improved'] < 0): ?>
                                            <span class="text-red-600 font-medium"><?php echo e($data['level_improved']); ?> <?php echo e(__('levels')); ?></span>
                                        <?php else: ?>
                                            <span class="text-gray-500">0</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-4 text-center text-sm text-gray-500">
                                        <?php echo e(__('No students with multiple assessments found')); ?>

                                        <div class="text-xs text-gray-400 mt-1">
                                            <?php echo e(__('Students need both baseline and follow-up assessments to appear in this report')); ?>

                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if(count($progressData) > 0): ?>
                    <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-800">
                        <p><strong><?php echo e(__('Note')); ?>:</strong> <?php echo e(__('This table shows students sorted by their level improvement. Students who moved up multiple levels appear first, followed by those with smaller improvements, then those who maintained their level, and finally those who declined.')); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Interpretation Guide -->
            <?php if(count($progressData) > 0): ?>
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-yellow-800"><?php echo e(__('Interpreting Progress Data')); ?></h3>
                        <div class="mt-2 text-sm text-yellow-700">
                            <ul class="list-disc list-inside space-y-1">
                                <li><strong><?php echo e(__('High improvement rates')); ?> (>70% improved):</strong> <?php echo e(__('Indicates effective teaching and learning interventions')); ?></li>
                                <li><strong><?php echo e(__('Mixed results')); ?> (30-70% improved):</strong> <?php echo e(__('Normal variation; consider individual student needs')); ?></li>
                                <li><strong><?php echo e(__('Low improvement rates')); ?> (<30% improved):</strong> <?php echo e(__('May indicate need for curriculum or teaching method review')); ?></li>
                                <li><strong><?php echo e(__('Students maintaining levels')); ?>:</strong> <?php echo e(__('Could be at appropriate challenge level or need different support')); ?></li>
                                <li><strong><?php echo e(__('Students declining')); ?>:</strong> <?php echo e(__('May need immediate attention and individualized intervention')); ?></li>
                                <li><strong><?php echo e(__('Consider timeframe')); ?>:</strong> <?php echo e(__('Progress between baseline and midline vs. baseline and endline may differ')); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Export and Actions -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4 class="text-md font-medium text-gray-900 mb-4"><?php echo e(__('Actions')); ?></h4>
                    
                    <div class="mb-3 text-sm text-gray-600">
                        <p><?php echo e(__('Use this progress data to identify students who need additional support, recognize successful teaching methods, and plan targeted interventions.')); ?></p>
                    </div>
                    
                    <div class="flex gap-4">
                        <?php if(count($progressData) > 0): ?>
                        <button onclick="exportChart()" class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 002 2v12a2 2 0 002 2z"></path>
                            </svg>
                            <?php echo e(__('Export Chart')); ?>

                        </button>
                        <?php endif; ?>
                        
                        <button onclick="window.print()" class="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
                            </svg>
                            <?php echo e(__('Print Report')); ?>

                        </button>
                        
                        <a href="<?php echo e(route('reports.student-performance')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v4a2 2 0 01-2 2h-2a2 2 0 00-2-2z"></path>
                            </svg>
                            <?php echo e(__('View Overall Performance')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script>
        let progressChart;
        
        <?php if(count($progressData) > 0): ?>
        $(document).ready(function() {
            const progressData = <?php echo json_encode($progressData, 15, 512) ?>;
            const levelChanges = progressData.reduce((acc, curr) => {
                const change = curr.level_improved;
                const key = change > 0 ? 'Improved' : (change < 0 ? 'Declined' : 'Maintained');
                acc[key] = (acc[key] || 0) + 1;
                return acc;
            }, {});
            
            // Create pie chart
            const ctx = document.getElementById('progressChart').getContext('2d');
            progressChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: Object.keys(levelChanges),
                    datasets: [{
                        data: Object.values(levelChanges),
                        backgroundColor: [
                            '#22c55e', // green for improved
                            '#ef4444', // red for declined
                            '#3b82f6'  // blue for maintained
                        ],
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        },
                        title: {
                            display: true,
                            text: '<?php echo e(__("Student Progress Distribution")); ?> - <?php echo e(ucfirst($subject)); ?>',
                            font: {
                                size: 16,
                                weight: 'bold'
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = ((context.raw / total) * 100).toFixed(1);
                                    return context.label + ': ' + context.raw + ' <?php echo e(__("students")); ?> (' + percentage + '%)';
                                }
                            }
                        },
                        datalabels: {
                            display: function(context) {
                                return context.dataset.data[context.dataIndex] > 0;
                            },
                            color: 'white',
                            font: {
                                weight: 'bold',
                                size: 12
                            },
                            formatter: function(value, context) {
                                const total = context.dataset.data.reduce((sum, val) => sum + val, 0);
                                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                return percentage > 0 ? percentage + '%' : '';
                            },
                            anchor: 'center',
                            align: 'center'
                        }
                    }
                },
                plugins: [ChartDataLabels]
            });
        });
        
        // Export chart function
        window.exportChart = function() {
            if (progressChart) {
                const subject = '<?php echo e($subject); ?>';
                const date = new Date().toISOString().split('T')[0];
                
                const link = document.createElement('a');
                link.download = 'progress-tracking-' + subject + '-' + date + '.png';
                link.href = progressChart.toBase64Image();
                link.click();
            }
        };
        <?php endif; ?>
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/reports/progress-tracking.blade.php ENDPATH**/ ?>