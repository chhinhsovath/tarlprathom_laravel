<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('About')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- About Section -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mb-6">
                <div class="p-6">
                    <div class="flex items-center mb-6">
                        <div class="h-16 w-16 bg-indigo-100 rounded-lg flex items-center justify-center mr-4">
                            <svg class="h-10 w-10 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                            </svg>
                        </div>
                        <div>
                            <h3 class="text-2xl font-bold text-gray-900"><?php echo e(__('TaRL Assessment System')); ?></h3>
                            <p class="text-gray-600"><?php echo e(__('Teaching at the Right Level')); ?></p>
                        </div>
                    </div>
                    
                    <div class="prose prose-indigo max-w-none">
                        <p class="text-gray-600">
                            <?php echo e(__('The TaRL Assessment System is a comprehensive educational platform designed to help teachers and mentors track student progress and improve learning outcomes through data-driven insights.')); ?>

                        </p>
                        
                        <h4 class="text-lg font-medium text-gray-900 mt-6 mb-3"><?php echo e(__('Our Mission')); ?></h4>
                        <p class="text-gray-600">
                            <?php echo e(__('To empower educators with tools that enable them to assess students effectively, identify learning gaps, and provide targeted interventions that help every child learn at their appropriate level.')); ?>

                        </p>
                        
                        <h4 class="text-lg font-medium text-gray-900 mt-6 mb-3"><?php echo e(__('Key Features')); ?></h4>
                        <ul class="list-disc list-inside text-gray-600 space-y-2">
                            <li><?php echo e(__('Comprehensive student assessment tracking')); ?></li>
                            <li><?php echo e(__('Real-time performance analytics and reporting')); ?></li>
                            <li><?php echo e(__('Multi-school management capabilities')); ?></li>
                            <li><?php echo e(__('Mentoring visit documentation')); ?></li>
                            <li><?php echo e(__('Progress tracking across multiple assessment cycles')); ?></li>
                            <li><?php echo e(__('Export capabilities for offline analysis')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- System Information -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                <div class="p-6">
                    <h4 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('System Information')); ?></h4>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm text-gray-500"><?php echo e(__('Version')); ?></p>
                            <p class="text-sm font-medium text-gray-900"><?php echo e($systemInfo['version']); ?></p>
                        </div>
                        
                        <div>
                            <p class="text-sm text-gray-500"><?php echo e(__('Laravel Version')); ?></p>
                            <p class="text-sm font-medium text-gray-900"><?php echo e($systemInfo['laravel_version']); ?></p>
                        </div>
                        
                        <div>
                            <p class="text-sm text-gray-500"><?php echo e(__('PHP Version')); ?></p>
                            <p class="text-sm font-medium text-gray-900"><?php echo e($systemInfo['php_version']); ?></p>
                        </div>
                        
                        <div>
                            <p class="text-sm text-gray-500"><?php echo e(__('Environment')); ?></p>
                            <p class="text-sm font-medium text-gray-900"><?php echo e(ucfirst($systemInfo['environment'])); ?></p>
                        </div>
                        
                        <div>
                            <p class="text-sm text-gray-500"><?php echo e(__('Timezone')); ?></p>
                            <p class="text-sm font-medium text-gray-900"><?php echo e($systemInfo['timezone']); ?></p>
                        </div>
                        
                        <div>
                            <p class="text-sm text-gray-500"><?php echo e(__('Default Language')); ?></p>
                            <p class="text-sm font-medium text-gray-900"><?php echo e(strtoupper($systemInfo['locale'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Credits -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mt-6">
                <div class="p-6">
                    <h4 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('Credits')); ?></h4>
                    <p class="text-gray-600 mb-4">
                        <?php echo e(__('This system was developed in collaboration with educational experts and technology partners to support the Teaching at the Right Level initiative.')); ?>

                    </p>
                    <div class="text-sm text-gray-500">
                        <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(__('TaRL Project. All rights reserved.')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/about.blade.php ENDPATH**/ ?>