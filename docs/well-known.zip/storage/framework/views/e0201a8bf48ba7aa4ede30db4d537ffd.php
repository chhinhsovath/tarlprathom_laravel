<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Assessment History')); ?>: <?php echo e($student->name); ?>

            </h2>
            <a href="<?php echo e(route('students.show', $student)); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                <?php echo e(__('Back to Student')); ?>

            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="w-full px-4 sm:px-6 lg:px-8">
            <!-- Student Info -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div>
                            <span class="font-semibold text-gray-600"><?php echo e(__('Name')); ?>:</span> 
                            <span class="text-lg"><?php echo e($student->name); ?></span>
                        </div>
                        <div>
                            <span class="font-semibold text-gray-600"><?php echo e(__('Student ID')); ?>:</span> 
                            <?php echo e($student->student_id); ?>

                        </div>
                        <div>
                            <span class="font-semibold text-gray-600"><?php echo e(__('Age')); ?>:</span> 
                            <?php echo e($student->age ?? 'N/A'); ?>

                        </div>
                        <div>
                            <span class="font-semibold text-gray-600"><?php echo e(__('Gender')); ?>:</span> 
                            <?php echo e($student->gender ? __(ucfirst($student->gender)) : 'N/A'); ?>

                        </div>
                        <div>
                            <span class="font-semibold text-gray-600"><?php echo e(__('Grade')); ?>:</span> 
                            <?php echo e($student->grade ? __('Grade') . ' ' . $student->grade : 'N/A'); ?>

                        </div>
                        <div>
                            <span class="font-semibold text-gray-600"><?php echo e(__('School')); ?>:</span> 
                            <?php echo e($student->school ? $student->school->name : 'N/A'); ?>

                        </div>
                        <?php if($student->teacher): ?>
                        <div class="md:col-span-2 lg:col-span-3">
                            <span class="font-semibold text-gray-600"><?php echo e(__('Teacher')); ?>:</span> 
                            <?php echo e($student->teacher->name); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Assessment History by Subject and Cycle -->
            <div class="space-y-6">
                <?php $__currentLoopData = ['khmer', 'math']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6 bg-white border-b border-gray-200">
                            <h3 class="text-lg font-semibold mb-4"><?php echo e(__($subject == 'khmer' ? 'Khmer' : 'Mathematics')); ?></h3>
                            
                            <div class="space-y-4">
                                <?php $__currentLoopData = ['baseline', 'midline', 'endline']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $key = $subject . '_' . $cycle;
                                        $currentAssessment = $currentAssessments->get($key);
                                        $historyItems = $histories->get($key, collect());
                                    ?>
                                    
                                    <div class="border rounded-lg p-4">
                                        <h4 class="font-semibold text-md mb-2"><?php echo e(__(ucfirst($cycle))); ?></h4>
                                        
                                        <?php if($currentAssessment): ?>
                                            <!-- Current Assessment -->
                                            <div class="bg-blue-50 rounded p-3 mb-3">
                                                <div class="flex justify-between items-center">
                                                    <div>
                                                        <span class="font-semibold"><?php echo e(__('Current Level')); ?>:</span> 
                                                        <span class="text-lg"><?php echo e($currentAssessment->level); ?></span>
                                                    </div>
                                                    <div class="text-sm text-gray-600">
                                                        <?php echo e(__('Assessed on')); ?>: <?php echo e($currentAssessment->assessed_at->format('d/m/Y')); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if($historyItems && $historyItems->count() > 0): ?>
                                            <!-- History Table -->
                                            <div class="overflow-x-auto">
                                                <table class="min-w-full divide-y divide-gray-200 mt-2">
                                                    <thead class="bg-gray-50">
                                                        <tr>
                                                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Date/Time')); ?></th>
                                                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Level')); ?></th>
                                                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Change')); ?></th>
                                                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Action')); ?></th>
                                                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Updated By')); ?></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="bg-white divide-y divide-gray-200">
                                                        <?php $__currentLoopData = $historyItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="<?php echo e($history->action == 'created' ? 'bg-green-50' : ''); ?>">
                                                                <td class="px-3 py-2 whitespace-nowrap text-sm">
                                                                    <?php echo e($history->created_at->format('d/m/Y H:i')); ?>

                                                                </td>
                                                                <td class="px-3 py-2 whitespace-nowrap text-sm font-medium">
                                                                    <?php echo e($history->level); ?>

                                                                </td>
                                                                <td class="px-3 py-2 whitespace-nowrap text-sm">
                                                                    <?php if($history->level_change): ?>
                                                                        <span class="text-gray-600"><?php echo e($history->level_change); ?></span>
                                                                    <?php else: ?>
                                                                        <span class="text-gray-400">-</span>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td class="px-3 py-2 whitespace-nowrap text-sm">
                                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                                        <?php echo e($history->action == 'created' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                                                        <?php echo e(__($history->action == 'created' ? 'Created' : 'Updated')); ?>

                                                                    </span>
                                                                </td>
                                                                <td class="px-3 py-2 whitespace-nowrap text-sm">
                                                                    <?php echo e($history->updatedBy ? $history->updatedBy->name : 'System'); ?>

                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php else: ?>
                                            <p class="text-gray-500 text-sm"><?php echo e(__('No assessment history for this cycle')); ?></p>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/dashfiyn/tarl.dashboardkh.com/resources/views/students/assessment-history.blade.php ENDPATH**/ ?>